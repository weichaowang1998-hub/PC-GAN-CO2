# PC-GAN: physics-constrained GAN augmentation for small-sample regression

Reference implementation accompanying the manuscript on physics-constrained
generative data augmentation for predicting CO₂ capture performance from
composition and process conditions.

The repository trains two generators — a **vanilla GAN** over the joint
`(features, target)` space and a **PC-GAN** additionally conditioned on physical
quantities — uses them to enlarge a small training set, and compares six
regressors across three data buckets: unaugmented, vanilla-augmented and
PC-GAN-augmented.

---

## Quick start

```bash
git clone <repository-url>
cd pcgan-co2

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Put the dataset at data/CO2-61-60-2.xlsx, then:
python scripts/run_experiment.py --config config/default.yaml
```

Check an installation without the real data:

```bash
python scripts/make_synthetic_data.py --out data/synthetic_demo.csv
python scripts/run_experiment.py --config config/default.yaml \
    --data data/synthetic_demo.csv --outdir results/smoke \
    --repeats 2 --epochs 20 --device cpu
```

Run the test suite:

```bash
pip install -r requirements-dev.txt
python -m pytest
```

---

## Repository layout

```
pcgan-co2/
├── config/
│   ├── default.yaml         # full experiment, strict methodology
│   └── legacy.yaml          # reproduces the original script's numbers
├── data/
│   ├── README.md            # column layout and data requirements
│   └── synthetic_demo.csv   # generated; safe to delete
├── scripts/
│   ├── run_experiment.py    # CLI entry point (no install required)
│   └── make_synthetic_data.py
├── src/pcgan/
│   ├── config.py            # dataclass configuration + validation
│   ├── data.py              # loading, column resolution, split, simplex projection
│   ├── gan.py               # generator/discriminator, training, sample selection
│   ├── models.py            # model factory and parameter-grid expansion
│   ├── evaluation.py        # cross-validated search, sample weights
│   ├── pipeline.py          # one split × three buckets × all models
│   ├── legacy.py            # faithful reproduction of the original script
│   ├── reporting.py         # aggregation, CSV export, figures
│   ├── runner.py            # orchestration and output
│   └── cli.py               # argument parsing
└── tests/                   # 41 tests, no real data required
```

---

## Methodology notes

This section states what the code does, including the places where a reader
would otherwise assume more than the implementation delivers.

### Two modes

`evaluation.mode` selects between two analysis paths.

**`strict` (default)** applies the corrections described below and evaluates
over `n_repeats` independent train/test splits, reporting mean ± standard
deviation plus a paired Wilcoxon signed-rank test. Headline numbers should come
from this mode.

**`legacy`** reproduces what the original single-script implementation did, so
that numbers already in a manuscript can still be regenerated. It is a
compatibility path, not a recommendation. `config/legacy.yaml` sets it up.

The differences are listed in [`docs/methodology.md`](docs/methodology.md).

### Symmetric hyperparameter tuning

Every model is searched over **the same `param_grid` on every bucket**. The
original script left the baselines at hand-picked constants while running large
grid searches for the augmented models, which confounds "augmentation helped"
with "tuning helped". With a single factory there is no way for the two sides to
diverge.

### Discriminator-based selection actually selects

A candidate pool of `gan.pool_factor × n_real` records is generated and the
top `gan.ratio × n_real` by discriminator score are kept. In the original
implementation the pool size equalled the number of records kept, so ranking
discarded nothing. `validate_config` rejects a `pool_factor` of 1.0 in strict
mode so this cannot recur silently.

### What the "physical constraint" is

`gan.constraint_mode` makes the distinction explicit:

- **`conditional`** (default, and what the original code implemented): the
  generator is penalised when its output physical columns deviate from the
  conditioning vector it was given. This constrains the synthetic physical
  block to be consistent with its own input; it does **not** encode a physical
  law relating features, target and physical quantities.
- **`mixture`**: adds a penalty on violation of a linear mixture rule across the
  physical block, configured by `gan.mixture_coefficients`. This is a genuine
  constraint on the generated outputs. Leave the coefficients unset unless such
  a relation holds for your system.

The active mode is recorded in `results/*/run_metadata.json`. Describe it
accurately in the paper.

### Compositional validity

Compositions are normalised to a unit sum on load, and synthetic compositions
are re-projected onto the simplex (clip at zero, renormalise) before entering
the augmented set. Without the projection the augmented table contains
physically impossible rows.

### Known limitation: CV optimism

Synthetic rows are fitted from the real training split only — the generator
never sees the test set. Within a bucket, however, the same synthetic rows are
shared across CV folds, so the CV score used for model selection is mildly
optimistic. The CV score is reported as a diagnostic; the test-set score is the
basis for every claim. Fixing this properly requires nesting the generator
inside the CV loop, which multiplies runtime by the fold count; it is left as an
explicit limitation rather than an unstated one.

### Sample weights

`ModelConfig.synth_weight` sets the weight on synthetic rows (real rows are
always 1.0). A weight of 1.0 means no weighting is applied at all, and
`evaluation.build_sample_weight` returns `None` in that case rather than
pretending weighted training happened. Set a value below 1.0 and run an ablation
before claiming that weighting contributes.

### Small samples

With a few dozen records, a single train/test split gives an RMSE whose
sampling noise can exceed any effect being measured. Strict mode therefore
repeats the split (`evaluation.n_repeats`, default 10) and reports dispersion
and a paired test. Treat any difference smaller than the reported standard
deviation as unresolved.

---

## Configuration

Everything is driven by `config/default.yaml`; no paths or hyperparameters are
hard-coded. Relative paths resolve against the YAML file's own directory, so the
repository is relocatable.

Common overrides:

```bash
python scripts/run_experiment.py --config config/default.yaml \
    --data data/CO2-61-60-2.xlsx \
    --outdir results/strict \
    --mode strict \
    --repeats 10 \
    --seed 42 \
    --epochs 500 \
    --device cuda
```

Validate a configuration and the data layout without running anything:

```bash
python scripts/run_experiment.py --config config/default.yaml --dry-run
```

Unknown keys in the YAML are an error rather than being silently ignored, so a
typo fails immediately instead of quietly falling back to a default.

---

## Outputs

Each run writes into `output.outdir`:

| File | Contents |
| --- | --- |
| `metrics_per_run.csv` | One row per (repeat, model, bucket) |
| `metrics_summary.csv` | Mean and std per (model, bucket) |
| `metrics_summary_wide.csv` | One row per model, buckets in columns |
| `metrics_delta_vs_reference.csv` | Relative change against the reference bucket |
| `statistical_tests.csv` | Paired Wilcoxon per model and bucket (multi-repeat only) |
| `selected_hyperparameters.csv` | Winning configuration per (repeat, model, bucket) |
| `predictions.csv` | Per-sample `y_true`, `y_pred`, `residual` |
| `datasets/` | Train/test split and augmented training sets for the first repeat |
| `run_metadata.json` | Data descriptors, GAN and tuning settings, environment |
| `environment.json` | Python and library versions |
| `rmse_by_bucket.png`, `r2_by_bucket.png` | Comparison figures |

`predictions.csv` and `selected_hyperparameters.csv` exist so that a reviewer can
recompute every reported metric without re-running the training. Predicting on
the test set once more and comparing against these files is the fastest way to
audit a result.

---

## Reproducibility

Global seeds (`random`, `numpy`, `torch`) are set per repeat, cuDNN
deterministic flags are enabled, and DataLoader shuffling uses an explicitly
seeded generator. Runs are reproducible on CPU and in practice on GPU; exact
bitwise agreement across different GPU models is not guaranteed.

To reproduce the published numbers, pin the versions in `requirements.txt` and
record `environment.json` from your run next to the results.

---

## Citing

See [`CITATION.cff`](CITATION.cff). Please cite both the paper and this
software.

## License

MIT — see [`LICENSE`](LICENSE). The dataset may carry separate terms; check
`data/README.md`.
