"""Faithful reproduction of the original single-script experiment.

This module exists so that the numbers in an already-submitted manuscript can
still be regenerated after the main pipeline was corrected. It is *not* a
recommended analysis path and the README says so. Behaviour reproduced
deliberately, warts included:

* a single train/test split, no repeats;
* baselines on hand-picked constants while the augmented models are tuned;
* discriminator selection over a candidate pool equal in size to the number of
  samples kept, so selection has no effect;
* synthetic samples drawn from a generator trained on the whole training set,
  then shared between CV folds;
* uniform sample weights for synthetic rows;
* compositions of synthetic rows not re-projected onto the simplex.

Anything that was a plain bug in the original (the removed
``squared=False`` argument, the blocking ``plt.show()``, absolute paths,
silently swallowed SVM errors) is *not* reproduced.

Known approximations relative to the original script: the PC-GAN KernelRidge
used a composite ``linear + RBF`` kernel implemented as a closure, which is not
picklable and cannot be searched cleanly; the grid here searches a plain RBF
kernel instead. KernelRidge is therefore close to, but not bit-identical with,
the originally reported values.
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from .config import Config, ModelConfig
from .data import Dataset
from .evaluation import fit_and_evaluate
from .gan import fit_gan_on, resolve_device, set_global_seed

# --------------------------------------------------------------------------- #
# Original hyperparameter grids
# --------------------------------------------------------------------------- #
LEGACY_KRR_GRID = [
    dict(alpha=alpha, gamma=g, kernel="rbf")
    for g in [0.25, 0.5, 1.0, 2.0, 4.0]
    for alpha in [1e-3, 3e-3, 1e-2, 3e-2, 1e-1, 3e-1, 1.0]
]

LEGACY_SVR_GRID = [
    dict(C=c, epsilon=e, kernel=k, gamma="scale")
    for c in [1.0, 10.0]
    for e in [0.05, 0.1]
    for k in ["rbf", "linear"]
]

LEGACY_LGBM_GRID = [
    {
        "learning_rate": lr, "n_estimators": ne, "num_leaves": nl,
        "max_depth": md, "min_child_samples": mcs,
        "feature_fraction": 0.8, "bagging_fraction": 0.8, "bagging_freq": 1,
        "lambda_l2": l2, "lambda_l1": 0.0, "min_split_gain": 1e-2,
    }
    for lr in [0.02, 0.03]
    for ne in [600, 900]
    for nl in [15, 31]
    for md in [6, 10]
    for mcs in [10, 20]
    for l2 in [3.0, 5.0]
]

LEGACY_XGB_GRID = [
    {
        "learning_rate": lr, "n_estimators": ne, "max_depth": md,
        "min_child_weight": mcw, "subsample": ss, "colsample_bytree": cs,
        "reg_lambda": l2, "reg_alpha": 0.0,
    }
    for lr in [0.01, 0.02]
    for ne in [500, 800]
    for md in [6, 8]
    for mcw in [1, 3]
    for ss in [0.8, 0.9]
    for cs in [0.8, 0.9]
    for l2 in [1.0, 3.0]
]

#: Fixed constants used for the "before" and "after (vanilla)" buckets.
LEGACY_FIXED: Dict[str, dict] = {
    "knn": {"n_neighbors": 6, "weights": "distance", "metric": "euclidean"},
    "kernelridge": {"alpha": 1.0, "gamma": 1.0, "kernel": "rbf"},
    "svr": {"kernel": "rbf", "C": 1.0, "epsilon": 0.1},
    "lightgbm": {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 31,
                 "reg_lambda": 1.0},
    "xgboost": {"n_estimators": 300, "learning_rate": 0.01, "max_depth": 6,
                "reg_lambda": 1.0},
    "mlp": {"hidden_layer_sizes": (256, 128, 64), "activation": "relu",
            "solver": "adam", "alpha": 1e-5, "learning_rate_init": 5e-4,
            "max_iter": 1000, "early_stopping": True, "n_iter_no_change": 20},
}

LEGACY_GRIDS: Dict[str, List[dict]] = {
    "kernelridge": LEGACY_KRR_GRID,
    "svr": LEGACY_SVR_GRID,
    "lightgbm": LEGACY_LGBM_GRID,
    "xgboost": LEGACY_XGB_GRID,
}


# --------------------------------------------------------------------------- #
# Legacy augmentation
# --------------------------------------------------------------------------- #
def legacy_augment(cfg: Config, train: Dataset, kind: str, seed: int,
                   device=None) -> Dataset:
    """Augment exactly as the original script did.

    The pool size equals the number of samples kept, so the discriminator
    ranking is a permutation that discards nothing. Compositions are left
    unprojected.
    """
    if kind == "before":
        return train
    device = device or resolve_device()
    n_real = train.n_samples
    keep = n_real
    pool = max(int(cfg.gan.pool_factor * n_real), n_real) if cfg.gan.pool_factor != 1.0 else n_real

    conditioned = kind == "after_pc"
    if conditioned and not train.has_phys:
        raise ValueError("PC-GAN bucket requested but the dataset has no phys columns")
    n_phys = train.phys.shape[1] if conditioned else 0

    records = np.hstack([train.X, train.y.reshape(-1, 1)])
    if conditioned:
        records = np.hstack([records, train.phys])

    fit = fit_gan_on(records, cfg.gan, n_phys=n_phys, device=device, seed=seed,
                     conditioned=conditioned,
                     label="PC-GAN" if conditioned else "Vanilla-GAN")

    phys_pool = None
    if conditioned:
        rng = np.random.default_rng(seed)
        phys_pool = train.phys[rng.integers(0, n_real, size=pool)]

    raw = fit.sample(pool, phys=phys_pool, seed=seed)
    scaled = fit.scaler.transform(raw).astype(np.float32)
    scores = fit.score(scaled)
    keep_idx = np.argsort(-scores)[:keep]
    raw = raw[keep_idx]

    n_feat = train.n_features
    return train.with_rows(raw[:, :n_feat], raw[:, n_feat],
                           raw[:, n_feat + 1:] if conditioned else None)


# --------------------------------------------------------------------------- #
# Legacy bucket evaluation
# --------------------------------------------------------------------------- #
def legacy_evaluate(
    cfg: Config,
    train: Dataset,
    test: Dataset,
    seed: int,
    device=None,
) -> Dict[str, Dict[str, object]]:
    """Evaluate every model on the three buckets the original way.

    Returns ``{model: {bucket: FitResult}}``.
    """
    set_global_seed(seed)
    device = device or resolve_device()

    buckets = {"before": train, "after": legacy_augment(cfg, train, "after", seed, device)}
    if train.has_phys:
        buckets["after_pc"] = legacy_augment(cfg, train, "after_pc", seed, device)

    out: Dict[str, Dict[str, object]] = {}
    for mcfg in cfg.models:
        if not mcfg.enabled:
            continue
        name = mcfg.name
        fixed = dict(LEGACY_FIXED.get(name, {}))
        grid = LEGACY_GRIDS.get(name)

        for bucket, ds in buckets.items():
            # The original tuned only the PC-GAN bucket; the other two used the
            # fixed constants unchanged.
            if bucket == "after_pc" and grid is not None:
                sub = ModelConfig(name=name, param_grid=grid, fixed_params=fixed,
                                  synth_weight=1.0)
            else:
                sub = ModelConfig(name=name, param_grid=[{}], fixed_params=fixed,
                                  synth_weight=1.0)
            r = fit_and_evaluate(
                sub, cfg.tuning, bucket,
                ds.X, ds.y, test.X, test.y,
                n_real=train.n_samples, seed=seed,
            )
            out.setdefault(name, {})[bucket] = r
    return out
