"""End-to-end experiment pipeline: one split, three buckets, all models.

The three buckets are:

``before``
    Real training data only.
``after``
    Real data plus vanilla-GAN samples (unconditional GAN trained on X and y).
``after_pc``
    Real data plus PC-GAN samples (conditional on the physical block).

In strict mode the generator for a bucket is fitted **inside each training
split only**, and the CV used for tuning is performed on the augmented training
bucket while the held-out test set is never touched. Synthetic rows are still
shared between the CV folds of a bucket, so the CV score remains mildly
optimistic; it is used for model selection and reported as a diagnostic, while
the test score is the basis for every claim. This limitation is stated in the
README rather than papered over.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np

from .config import Config
from .data import Dataset, project_to_simplex
from .evaluation import FitResult, fit_and_evaluate
from .gan import fit_gan_on, resolve_device, select_samples, set_global_seed

BUCKETS = ("before", "after", "after_pc")


# --------------------------------------------------------------------------- #
# Augmentation
# --------------------------------------------------------------------------- #
def augment_dataset(
    cfg: Config,
    train: Dataset,
    kind: str,
    seed: int,
    device=None,
) -> Dataset:
    """Return ``train`` with synthetic rows appended.

    ``kind`` is ``"after"`` (vanilla) or ``"after_pc"`` (physics-constrained).
    The number of synthetic rows is ``gan.ratio * n_real``, drawn from a pool
    ``gan.pool_factor`` times larger and selected by discriminator score.
    """
    if kind == "before":
        return train
    if kind not in {"after", "after_pc"}:
        raise ValueError(f"Unknown augmentation kind {kind!r}")

    device = device or resolve_device()
    gan_cfg = cfg.gan
    n_real = train.n_samples
    keep = max(1, int(round(gan_cfg.ratio * n_real)))
    pool = max(int(round(gan_cfg.pool_factor * keep)), keep + 1)

    if kind == "after_pc" and not train.has_phys:
        raise ValueError(
            "PC-GAN augmentation requires physical-constraint columns, "
            "but data.phys_columns is empty"
        )

    conditioned = kind == "after_pc"
    n_phys = train.phys.shape[1] if conditioned else 0

    records = np.hstack([train.X, train.y.reshape(-1, 1)])
    if conditioned:
        records = np.hstack([records, train.phys])

    fit = fit_gan_on(
        records, gan_cfg, n_phys=n_phys, device=device, seed=seed,
        conditioned=conditioned,
        label="PC-GAN" if conditioned else "Vanilla-GAN",
    )

    phys_pool = None
    if conditioned:
        rng = np.random.default_rng(seed)
        phys_pool = train.phys[rng.integers(0, n_real, size=pool)]

    raw, _scores = select_samples(fit, pool_size=pool, keep=keep,
                                  phys_pool=phys_pool, seed=seed)

    n_feat = train.n_features
    X_syn = raw[:, :n_feat]
    y_syn = raw[:, n_feat]
    phys_syn = raw[:, n_feat + 1:] if conditioned else None

    # Generated records are unconstrained: re-project compositions onto the
    # simplex so the augmented table contains physically admissible rows.
    if train.composition_idx:
        X_syn = project_to_simplex(X_syn, train.composition_idx)

    return train.with_rows(X_syn, y_syn, phys_syn)


# --------------------------------------------------------------------------- #
# One split, all buckets, all models
# --------------------------------------------------------------------------- #
@dataclass
class SplitResult:
    """All model outcomes for a single train/test split."""

    repeat: int
    seed: int
    results: Dict[str, Dict[str, FitResult]] = field(default_factory=dict)
    test_labels: Optional[np.ndarray] = None

    def add(self, r: FitResult) -> None:
        self.results.setdefault(r.model, {})[r.bucket] = r

    def flat_rows(self) -> List[dict]:
        """One row per (model, bucket) for tabular export."""
        rows = []
        for model, buckets in self.results.items():
            for bucket, r in buckets.items():
                rows.append({
                    "repeat": self.repeat,
                    "split_seed": self.seed,
                    "model": model,
                    "bucket": bucket,
                    "RMSE": r.test["RMSE"],
                    "R2": r.test["R2"],
                    "MAE": r.test["MAE"],
                    "cv_rmse": r.cv_rmse,
                    "cv_rmse_std": r.cv_rmse_std,
                    "n_train": r.n_train,
                    "n_synthetic": r.n_synthetic,
                })
        return rows


def run_split(
    cfg: Config,
    train: Dataset,
    test: Dataset,
    repeat: int,
    seed: int,
    device=None,
    log: Callable[[str], None] = print,
) -> SplitResult:
    """Run every bucket and every enabled model for one train/test split."""
    set_global_seed(seed)
    device = device or resolve_device()
    out = SplitResult(repeat=repeat, seed=seed, test_labels=test.y.copy())

    buckets = _buckets_for(cfg, train)
    datasets: Dict[str, Dataset] = {}
    for bucket in buckets:
        if bucket == "before":
            datasets[bucket] = train
        else:
            log(f"  [repeat {repeat}] training {bucket} generator (seed={seed})")
            datasets[bucket] = augment_dataset(cfg, train, bucket, seed=seed, device=device)

    for mcfg in cfg.models:
        if not mcfg.enabled:
            continue
        for bucket in buckets:
            ds = datasets[bucket]
            log(f"  [repeat {repeat}] fit {mcfg.name} on {bucket} "
                f"(n={ds.n_samples}, synth={ds.n_samples - train.n_samples})")
            r = fit_and_evaluate(
                mcfg, cfg.tuning, bucket,
                ds.X, ds.y, test.X, test.y,
                n_real=train.n_samples,
                seed=seed,
            )
            out.add(r)
    return out


def _buckets_for(cfg: Config, train: Dataset) -> tuple:
    """Which buckets are runnable for this dataset and configuration."""
    buckets = ["before", "after"]
    if train.has_phys:
        buckets.append("after_pc")
    else:
        print(
            "Note: data.phys_columns is empty, so the PC-GAN bucket is skipped. "
            "Only the vanilla-GAN comparison is available."
        )
    return tuple(buckets)
