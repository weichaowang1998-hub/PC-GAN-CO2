"""Cross-validated model fitting, tuning and prediction.

Two guarantees this module provides that the original implementation did not:

* **Deterministic, explicit tuning.** Every candidate in the grid is evaluated
  on identical folds, and the winning candidate is refitted on the full bucket.
* **Synthetic rows never leak into validation.** The GAN is fitted only on the
  real training portion of each fold (see :mod:`pcgan.pipeline`); this module
  only ever receives a bucket whose composition it does not need to reason
  about.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from sklearn.model_selection import KFold

from .config import ModelConfig, TuningConfig
from .metrics import regression_metrics
from .models import build_pipeline, expand_params


# --------------------------------------------------------------------------- #
# Results
# --------------------------------------------------------------------------- #
@dataclass
class FitResult:
    """Outcome of fitting one model on one data bucket."""

    model: str
    bucket: str
    params: Dict[str, Any]
    cv_rmse: float
    cv_rmse_std: float
    test: Dict[str, float]
    n_train: int
    n_synthetic: int
    y_pred: Optional[np.ndarray] = None


# --------------------------------------------------------------------------- #
# Sample weights
# --------------------------------------------------------------------------- #
def build_sample_weight(n_real: int, n_total: int, synth_weight: float) -> Optional[np.ndarray]:
    """Weights with real rows at 1.0 and synthetic rows at ``synth_weight``.

    Returns ``None`` when no weighting is actually implied, so that the
    fitting path stays identical to the unweighted one. Reporting "weighted
    training" while using a weight of 1.0 for every row is a claim the code
    would not support, so that case is made explicit.
    """
    n_syn = n_total - n_real
    if n_syn < 0:
        raise ValueError(f"n_total ({n_total}) is smaller than n_real ({n_real})")
    if n_syn == 0:
        return None
    if np.isclose(synth_weight, 1.0):
        return None
    return np.concatenate([np.full(n_real, 1.0), np.full(n_syn, float(synth_weight))])


# --------------------------------------------------------------------------- #
# Candidate expansion
# --------------------------------------------------------------------------- #
def candidate_params(mcfg: ModelConfig, tuning: TuningConfig) -> List[Dict[str, Any]]:
    """Flatten a model's grid into a list of prefixed parameter dicts."""
    out: List[Dict[str, Any]] = []
    for entry in mcfg.param_grid or [{}]:
        out.extend(
            expand_params(mcfg.name, entry, mcfg.fixed_params, seed=tuning.random_state)
        )
    return out


def _supports_sample_weight(model) -> bool:
    """Cheap check for ``sample_weight`` support via fit signature."""
    import inspect

    est = model
    if hasattr(est, "regressor"):
        est = est.regressor
    if hasattr(est, "named_steps"):
        est = est.named_steps.get("model", est)
    try:
        return "sample_weight" in inspect.signature(est.fit).parameters
    except (TypeError, ValueError):
        return False


# --------------------------------------------------------------------------- #
# Cross-validated search
# --------------------------------------------------------------------------- #
def cv_search(
    mcfg: ModelConfig,
    tuning: TuningConfig,
    X_train: np.ndarray,
    y_train: np.ndarray,
    sample_weight: Optional[np.ndarray] = None,
    seed: Optional[int] = None,
) -> Tuple[Dict[str, Any], float, float]:
    """Score every candidate with K-fold CV and return the best.

    Returns ``(best_params, mean_cv_rmse, std_cv_rmse)``. The RMSE is computed
    on the original response scale, so it is comparable across models with
    different internal transforms.
    """
    seed = tuning.random_state if seed is None else seed
    candidates = candidate_params(mcfg, tuning)
    if not candidates:
        candidates = [{}]

    n = X_train.shape[0]
    n_splits = min(tuning.cv_folds, n)
    if n_splits < 2:
        raise ValueError(
            f"Cannot cross-validate {mcfg.name!r}: the training bucket has {n} row(s)"
        )
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)

    best_params: Dict[str, Any] = candidates[0]
    best_mean = float("inf")
    best_std = 0.0

    for params in candidates:
        rmses: List[float] = []
        for tr_idx, va_idx in kf.split(X_train):
            model, _ = build_pipeline(mcfg.name, {}, seed)
            model.set_params(**params)
            sw = sample_weight[tr_idx] if sample_weight is not None else None
            _fit(model, X_train[tr_idx], y_train[tr_idx], sw)
            pred = model.predict(X_train[va_idx])
            rmses.append(float(np.sqrt(np.mean((pred - y_train[va_idx]) ** 2))))
        mean_rmse = float(np.mean(rmses))
        if mean_rmse < best_mean:
            best_mean = mean_rmse
            best_std = float(np.std(rmses))
            best_params = params

    return best_params, best_mean, best_std


def _fit(model, X: np.ndarray, y: np.ndarray, sample_weight: Optional[np.ndarray]) -> None:
    """Fit ``model``, forwarding sample weights only where the estimator accepts them."""
    if sample_weight is None:
        model.fit(X, y)
        return
    if not _supports_sample_weight(model):
        model.fit(X, y)
        return
    # TransformedTargetRegressor forwards the weight to the inner estimator.
    model.fit(X, y, **{"regressor__model__sample_weight": sample_weight})


# --------------------------------------------------------------------------- #
# Fit + evaluate one bucket
# --------------------------------------------------------------------------- #
def fit_and_evaluate(
    mcfg: ModelConfig,
    tuning: TuningConfig,
    bucket: str,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    n_real: int,
    seed: Optional[int] = None,
) -> FitResult:
    """Tune on the training bucket, refit, and score on the held-out test set."""
    n_total = X_train.shape[0]
    sw = build_sample_weight(n_real, n_total, mcfg.synth_weight)

    params, cv_mean, cv_std = cv_search(mcfg, tuning, X_train, y_train, sw, seed)

    model, _ = build_pipeline(mcfg.name, {}, seed if seed is not None else tuning.random_state)
    model.set_params(**params)
    _fit(model, X_train, y_train, sw)

    y_pred = model.predict(X_test)
    scores = regression_metrics(y_test, y_pred)

    return FitResult(
        model=mcfg.name,
        bucket=bucket,
        params=params,
        cv_rmse=cv_mean,
        cv_rmse_std=cv_std,
        test=scores,
        n_train=n_total,
        n_synthetic=n_total - n_real,
        y_pred=y_pred,
    )


def params_to_json(result: FitResult) -> str:
    """Serialise search results, coercing numpy scalars that json rejects."""
    def _clean(obj):
        if isinstance(obj, dict):
            return {k: _clean(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_clean(v) for v in obj]
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return obj

    return json.dumps(_clean(result.params), sort_keys=True)
