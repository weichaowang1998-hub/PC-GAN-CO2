"""Top-level experiment orchestration.

``run`` is the single entry point used by the CLI and by the test suite: it
loads the dataset, iterates over independent splits, calls the strict or legacy
pipeline, and writes every artefact under ``output.outdir``.
"""

from __future__ import annotations

import platform
import sys
from pathlib import Path
from typing import List, Optional

from . import __version__
from .config import Config, validate_config
from .data import Dataset, load_dataset, repeated_splits, split_dataset
from .gan import resolve_device
from .legacy import legacy_evaluate
from .pipeline import SplitResult, augment_dataset, run_split
from .reporting import (
    delta_table,
    export_results,
    plot_metric_comparison,
    significance_table,
    wide_summary,
)


def _banner(msg: str) -> None:
    print("\n" + "=" * 8 + " " + msg + " " + "=" * 8)


def _environment_summary() -> dict:
    """Record the versions that produced these numbers."""
    env = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "pcgan": __version__,
    }
    for mod in ("numpy", "pandas", "sklearn", "scipy", "torch", "lightgbm", "xgboost"):
        try:
            m = __import__(mod)
            env[mod] = getattr(m, "__version__", "unknown")
        except ImportError:
            env[mod] = None
    return env


def _write_environment(outdir: Path, env: dict) -> None:
    import json

    outdir.mkdir(parents=True, exist_ok=True)
    with open(outdir / "environment.json", "w", encoding="utf-8") as fh:
        json.dump(env, fh, indent=2, sort_keys=True)


def _export_datasets(cfg: Config, train: Dataset, test: Dataset, seed: int,
                     torch_device, outdir: Path) -> None:
    """Write the split and the augmented training sets for repeat 0.

    Only the first split is exported: dumping every repeat would multiply the
    archive size for no benefit, and the splits are fully determined by their
    seed. Synthetic files are regenerated with the same seed as the run, so
    they match what the models actually saw.
    """
    ds_dir = outdir / "datasets"
    ds_dir.mkdir(parents=True, exist_ok=True)

    split_tag = f"seed{seed}"
    train.frame().to_csv(ds_dir / f"train_{split_tag}.csv", index=False)
    test.frame().to_csv(ds_dir / f"test_{split_tag}.csv", index=False)

    for bucket, kind in (("augmented_vanilla", "after"), ("augmented_pc", "after_pc")):
        if kind == "after_pc" and not train.has_phys:
            continue
        aug = augment_dataset(cfg, train, kind, seed=seed, device=torch_device)
        aug.frame().to_csv(ds_dir / f"train_{bucket}_{split_tag}.csv", index=False)


def run(cfg: Config, dataset: Optional[Dataset] = None,
        device: Optional[str] = None) -> dict:
    """Execute the configured experiment and return the exported tables.

    Parameters
    ----------
    cfg:
        A validated configuration. :func:`validate_config` is called here so
        that programmatic callers get the same checks as the CLI.
    dataset:
        Optional pre-loaded dataset, mainly for tests.
    device:
        Torch device string (``"cpu"``/``"cuda"``); auto-detected when omitted.
    """
    validate_config(cfg)
    outdir = Path(cfg.output.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    env = _environment_summary()
    _write_environment(outdir, env)

    _banner("CONFIGURATION")
    print(f"mode              : {cfg.evaluation.mode}")
    print(f"data              : {cfg.data.path}")
    print(f"outdir            : {outdir}")
    print(f"device            : {device or resolve_device()}")
    print(f"models            : {[m.name for m in cfg.models if m.enabled]}")
    print(f"repeats           : {cfg.evaluation.n_repeats}")
    print(f"gan.constraint    : {cfg.gan.constraint_mode}")
    print(f"gan.pool_factor   : {cfg.gan.pool_factor}")

    _banner("LOAD DATA")
    ds = dataset if dataset is not None else load_dataset(cfg.data)
    print(f"samples           : {ds.n_samples}")
    print(f"features          : {ds.feature_names}")
    print(f"target            : {ds.target_name}")
    print(f"physical          : {ds.phys_names or 'none (PC-GAN unavailable)'}")
    if ds.composition_idx:
        names = [ds.feature_names[i] for i in ds.composition_idx]
        print(f"compositions      : {names} (normalised: {cfg.data.normalize_composition})")

    torch_device = resolve_device(device)
    results: List[SplitResult] = []
    first_train = first_test = None
    first_seed = cfg.data.random_state

    if cfg.evaluation.mode == "legacy":
        _banner("LEGACY MODE (single split, original methodology)")
        train, test = split_dataset(ds, cfg.data.test_size, cfg.data.random_state)
        print(f"train {train.n_samples} / test {test.n_samples}")
        first_train, first_test = train, test
        outcome = legacy_evaluate(cfg, train, test, seed=cfg.data.random_state,
                                  device=torch_device)
        sr = SplitResult(repeat=0, seed=cfg.data.random_state, test_labels=test.y.copy())
        for buckets in outcome.values():
            for r in buckets.values():
                sr.add(r)
        results.append(sr)
    else:
        _banner(f"STRICT MODE ({cfg.evaluation.n_repeats} repeats)")
        for k, seed, train, test in repeated_splits(
            ds, cfg.data.test_size, cfg.data.random_state, cfg.evaluation.n_repeats
        ):
            if k == 0:
                first_train, first_test, first_seed = train, test, seed
            print(f"\n--- repeat {k + 1}/{cfg.evaluation.n_repeats} "
                  f"(split seed {seed}; train {train.n_samples} / test {test.n_samples})")
            results.append(run_split(cfg, train, test, repeat=k, seed=seed,
                                     device=torch_device))

    if cfg.output.save_datasets and first_train is not None:
        _banner("EXPORT DATASETS")
        _export_datasets(cfg, first_train, first_test, first_seed, torch_device, outdir)
        print(f"train/test and augmented sets written to {outdir / 'datasets'}")

    _banner("SUMMARISE")
    tables = export_results(cfg, results, ds, outdir)

    summary = tables.get("summary")
    if summary is not None and not summary.empty:
        print(wide_summary(summary).to_string(index=False))
        if cfg.evaluation.n_repeats > 1:
            deltas = delta_table(summary, cfg.evaluation.reference_bucket)
            print("\nRelative change vs reference bucket "
                  f"({cfg.evaluation.reference_bucket}):")
            print(deltas.to_string(index=False))
        if cfg.evaluation.paired_test and cfg.evaluation.n_repeats > 1:
            sig = significance_table(results, cfg)
            if not sig.empty:
                print("\nPaired Wilcoxon signed-rank test (RMSE):")
                print(sig.to_string(index=False))

    if summary is not None and not summary.empty:
        for metric in ("RMSE", "R2"):
            path = plot_metric_comparison(summary, metric, outdir, dpi=cfg.output.dpi)
            if path:
                print(f"saved figure      : {path}")

    print(f"\nAll results written to {outdir}")
    return tables
