"""Data loading, column resolution, composition handling and splitting.

The original script derived every column role from its position in the
spreadsheet (columns 0-6 features, 7 target, 8-10 physical quantities). That
convention is preserved for the default configuration but is now validated
explicitly and can be replaced with column names.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence

import numpy as np
import pandas as pd

from .config import ColumnRef, DataConfig


# --------------------------------------------------------------------------- #
# Container
# --------------------------------------------------------------------------- #
@dataclass
class Dataset:
    """Numeric arrays plus the column names they came from."""

    X: np.ndarray
    y: np.ndarray
    phys: Optional[np.ndarray]
    feature_names: List[str]
    target_name: str
    phys_names: List[str]
    #: Indices into ``X`` that are compositions, after resolution.
    composition_idx: List[int]

    @property
    def n_samples(self) -> int:
        return int(self.X.shape[0])

    @property
    def n_features(self) -> int:
        return int(self.X.shape[1])

    @property
    def has_phys(self) -> bool:
        return self.phys is not None and self.phys.size > 0

    def subset(self, idx: np.ndarray) -> "Dataset":
        """Return a copy restricted to ``idx``."""
        return Dataset(
            X=self.X[idx],
            y=self.y[idx],
            phys=None if self.phys is None else self.phys[idx],
            feature_names=list(self.feature_names),
            target_name=self.target_name,
            phys_names=list(self.phys_names),
            composition_idx=list(self.composition_idx),
        )

    def frame(self) -> pd.DataFrame:
        """Rebuild a labelled DataFrame in the original column order."""
        parts = [self.X, self.y.reshape(-1, 1)]
        names = list(self.feature_names) + [self.target_name]
        if self.phys is not None:
            parts.append(self.phys)
            names += list(self.phys_names)
        return pd.DataFrame(np.hstack(parts), columns=names)

    def with_rows(self, X_extra: np.ndarray, y_extra: np.ndarray,
                  phys_extra: Optional[np.ndarray] = None) -> "Dataset":
        """Return a new dataset with extra rows appended.

        If this dataset carries physical quantities but ``phys_extra`` is not
        supplied, the physical block is dropped from the result rather than
        left shorter than the feature block. That case arises for the
        vanilla-GAN bucket, whose synthetic rows have no physical columns
        because the generator was never conditioned on them; modelling never
        reads ``phys``, so dropping it beats inventing values.
        """
        X = np.vstack([self.X, X_extra])
        y = np.concatenate([self.y, y_extra])
        phys = self.phys
        if phys is not None:
            if phys_extra is None:
                phys = None
            else:
                phys = np.vstack([phys, phys_extra])
        return Dataset(
            X=X, y=y, phys=phys,
            feature_names=list(self.feature_names),
            target_name=self.target_name,
            phys_names=list(self.phys_names) if phys is not None else [],
            composition_idx=list(self.composition_idx),
        )


# --------------------------------------------------------------------------- #
# Column resolution
# --------------------------------------------------------------------------- #
def _resolve(ref: ColumnRef, columns: Sequence[str], role: str) -> str:
    """Map a name-or-index reference onto an actual column name."""
    if isinstance(ref, (int, np.integer)):
        if ref < 0 or ref >= len(columns):
            raise IndexError(
                f"{role} column index {ref} is out of range for a table with "
                f"{len(columns)} columns: {list(columns)}"
            )
        return columns[int(ref)]
    if ref in columns:
        return ref
    raise KeyError(
        f"{role} column {ref!r} not found. Available columns: {list(columns)}"
    )


def resolve_columns(df: pd.DataFrame, cfg: DataConfig) -> tuple[List[str], str, List[str], List[int]]:
    """Resolve the four column groups against ``df`` and check they are disjoint."""
    cols = list(df.columns)
    features = [_resolve(c, cols, "feature") for c in cfg.feature_columns]
    target = _resolve(cfg.target_column, cols, "target")
    phys = [_resolve(c, cols, "phys") for c in (cfg.phys_columns or [])]
    comps = [_resolve(c, cols, "composition") for c in (cfg.composition_columns or [])]

    if len(set(features)) != len(features):
        raise ValueError(f"Duplicate feature columns requested: {features}")
    if target in features:
        raise ValueError(f"Target column {target!r} is also listed as a feature")
    overlap = set(features) & set(phys)
    if overlap:
        raise ValueError(f"Columns listed as both feature and physical quantity: {sorted(overlap)}")
    missing_comp = [c for c in comps if c not in features]
    if missing_comp:
        raise ValueError(
            f"Composition columns must also be feature columns; missing: {missing_comp}"
        )

    comp_idx = [features.index(c) for c in comps]
    return features, target, phys, comp_idx


# --------------------------------------------------------------------------- #
# Composition handling
# --------------------------------------------------------------------------- #
def normalize_compositions(X: np.ndarray, comp_idx: Sequence[int]) -> np.ndarray:
    """Rescale the composition block of each row to a unit sum.

    Rows whose composition sum is zero are left untouched rather than being
    divided by an epsilon, which would otherwise manufacture a one-hot row out
    of missing data.
    """
    if not comp_idx:
        return X
    X = np.array(X, dtype=float, copy=True)
    comp = X[:, list(comp_idx)]
    sums = comp.sum(axis=1, keepdims=True)
    nonzero = np.abs(sums[:, 0]) > 1e-12
    comp[nonzero] = comp[nonzero] / sums[nonzero]
    X[:, list(comp_idx)] = comp
    return X


def project_to_simplex(X: np.ndarray, comp_idx: Sequence[int]) -> np.ndarray:
    """Clip compositions to be non-negative and renormalise.

    Generated samples leave the GAN unconstrained, so a synthetic composition
    can be negative or fail to sum to one. Without this projection the
    augmented training file contains rows that are physically impossible, which
    is both a modelling error and something a reader will notice.
    """
    if not comp_idx:
        return X
    X = np.array(X, dtype=float, copy=True)
    idx = list(comp_idx)
    comp = np.clip(X[:, idx], 0.0, None)
    sums = comp.sum(axis=1, keepdims=True)
    # Fall back to a uniform composition when clipping zeroes an entire row.
    degenerate = sums[:, 0] <= 1e-12
    if np.any(degenerate):
        comp[degenerate] = 1.0
        sums = comp.sum(axis=1, keepdims=True)
    X[:, idx] = comp / sums
    return X


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def read_table(path: str | Path, sheet: Optional[str] = None) -> pd.DataFrame:
    """Read a CSV or Excel file, keeping the header row as column names."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Data file not found: {path}\n"
            "Place the dataset under data/ and set data.path in the configuration, "
            "or pass --data on the command line."
        )
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls", ".xlsm"}:
        return pd.read_excel(path, sheet_name=sheet if sheet is not None else 0, header=0)
    if suffix in {".csv", ".txt"}:
        return pd.read_csv(path)
    raise ValueError(f"Unsupported data format {suffix!r}; expected CSV or Excel")


def load_dataset(cfg: DataConfig) -> Dataset:
    """Load the configured table into a :class:`Dataset`."""
    df = read_table(cfg.path, cfg.sheet)
    features, target, phys, comp_idx = resolve_columns(df, cfg)

    try:
        X = df[features].to_numpy(dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"Feature columns must be numeric; failed to convert {features}: {exc}"
        ) from exc
    try:
        y = df[target].to_numpy(dtype=float).ravel()
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Target column {target!r} must be numeric: {exc}") from exc

    if not np.all(np.isfinite(X)):
        bad = int((~np.isfinite(X)).any(axis=1).sum())
        raise ValueError(f"{bad} row(s) contain NaN or infinite feature values")
    if not np.all(np.isfinite(y)):
        bad = int((~np.isfinite(y)).sum())
        raise ValueError(f"{bad} row(s) contain NaN or infinite target values")

    phys_arr = None
    if phys:
        phys_arr = df[phys].to_numpy(dtype=float)
        if not np.all(np.isfinite(phys_arr)):
            raise ValueError("Physical-constraint columns contain NaN or infinite values")

    if cfg.normalize_composition and comp_idx:
        X = normalize_compositions(X, comp_idx)

    return Dataset(
        X=X, y=y, phys=phys_arr,
        feature_names=features, target_name=target, phys_names=phys,
        composition_idx=comp_idx,
    )


# --------------------------------------------------------------------------- #
# Splitting
# --------------------------------------------------------------------------- #
def split_dataset(ds: Dataset, test_size: float, seed: int):
    """Single stratified-by-value split returning ``(train, test)``."""
    from sklearn.model_selection import train_test_split

    idx = np.arange(ds.n_samples)
    train_idx, test_idx = train_test_split(
        idx, test_size=test_size, random_state=seed, shuffle=True
    )
    return ds.subset(train_idx), ds.subset(test_idx)


def repeated_splits(ds: Dataset, test_size: float, base_seed: int, n_repeats: int):
    """Yield ``(repeat_index, seed, train, test)`` for independent splits.

    With a few dozen samples a single split gives an RMSE with very large
    sampling noise, so every headline number is reported over repeats rather
    than once.
    """
    for k in range(n_repeats):
        seed = base_seed + k
        train, test = split_dataset(ds, test_size=test_size, seed=seed)
        yield k, seed, train, test
