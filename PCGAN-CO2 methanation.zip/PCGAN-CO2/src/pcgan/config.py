"""Configuration objects for the PC-GAN experiments.

All experiment settings live here so that the pipeline contains no literal
paths or hyperparameters. A configuration is normally loaded from a YAML file
(see ``config/default.yaml``) via :func:`load_config`; every field can also be
overridden from the command line.

Design rule: column selection is explicit. The original script addressed
columns positionally, which fails silently when a spreadsheet is reordered.
Here features, target and physical-constraint columns are each named (or given
explicit 0-based indices), and :mod:`pcgan.data` validates the selection
against the loaded frame.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

import yaml

ColumnRef = Union[str, int]


# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
@dataclass
class DataConfig:
    """Where the data comes from and how it is laid out."""

    path: str = "data/CO2-61-60-2.xlsx"
    sheet: Optional[str] = None
    #: Feature columns, by name or 0-based index. Must be non-empty.
    feature_columns: List[ColumnRef] = field(default_factory=lambda: list(range(7)))
    #: Target (response) column, by name or 0-based index.
    target_column: ColumnRef = 7
    #: Columns holding the physical quantities used as GAN conditioning.
    #: ``None`` or empty disables the physics-constrained branch.
    phys_columns: List[ColumnRef] = field(default_factory=list)
    #: Which feature columns are compositions (normalised to sum to one).
    composition_columns: List[ColumnRef] = field(default_factory=list)
    #: If True, composition columns are rescaled to a unit sum before anything
    #: else, and synthetic compositions are re-projected onto the simplex.
    normalize_composition: bool = True
    #: Fraction of the data held out as the test set.
    test_size: float = 0.2
    #: Base seed for the train/test split.
    random_state: int = 42


# --------------------------------------------------------------------------- #
# GAN
# --------------------------------------------------------------------------- #
@dataclass
class GanConfig:
    """Architecture and training schedule shared by both GAN variants."""

    z_dim: int = 32
    hidden_g: Sequence[int] = (128, 256)
    hidden_d: Sequence[int] = (256, 128)
    epochs: int = 500
    batch_size: int = 16
    lr_g: float = 1e-4
    lr_d: float = 5e-5
    beta1: float = 0.5
    beta2: float = 0.999
    #: One-sided label smoothing applied to real samples.
    real_label: float = 0.9
    #: Size of the candidate pool relative to the real training set. Values
    #: <= 1.0 make discriminator-based selection a no-op, so the pipeline
    #: rejects them in strict mode.
    pool_factor: float = 3.0
    #: Weight of the physical-constraint penalty in the generator loss.
    lambda_phys: float = 8.0
    #: ``"conditional"`` penalises deviation between sampled and generated
    #: physical values (the behaviour of the original implementation).
    #: ``"mixture"`` additionally penalises violation of a linear mixture rule
    #: configured by ``mixture_coefficients``.
    constraint_mode: str = "conditional"
    mixture_coefficients: Optional[List[float]] = None
    #: How many synthetic samples to draw per real sample.
    ratio: float = 1.0
    #: If True, the generator is re-trained inside every CV fold so that
    #: synthetic samples never leak across the fold boundary.
    nested: bool = True
    verbose_every: int = 50


# --------------------------------------------------------------------------- #
# Models and tuning
# --------------------------------------------------------------------------- #
@dataclass
class ModelConfig:
    """A regression model plus the hyperparameter space searched for it.

    The same ``param_grid`` is searched on the unaugmented, vanilla-augmented
    and PC-GAN-augmented training sets. This symmetry is deliberate: it is what
    makes the augmentation comparison interpretable. Use ``param_grid: [{}]``
    to disable tuning for a model.
    """

    name: str
    enabled: bool = True
    param_grid: List[Dict[str, Any]] = field(default_factory=lambda: [{}])
    #: Fixed parameters merged into every candidate (not searched over).
    fixed_params: Dict[str, Any] = field(default_factory=dict)
    #: Weight applied to synthetic rows during fitting.
    synth_weight: float = 1.0


@dataclass
class TuningConfig:
    cv_folds: int = 5
    #: ``"grid"`` exhaustively evaluates ``param_grid``; ``"random"`` samples
    #: ``n_iter`` candidates with a fixed seed.
    search: str = "grid"
    n_iter: int = 20
    n_jobs: int = 1
    #: Inner-fold seed offset. Kept separate from the split seed so that tuning
    #: is deterministic given a split.
    random_state: int = 42


# --------------------------------------------------------------------------- #
# Evaluation
# --------------------------------------------------------------------------- #
@dataclass
class EvalConfig:
    #: ``"strict"`` applies the corrected methodology. ``"legacy"`` reproduces
    #: the numbers reported by the original single-script implementation.
    mode: str = "strict"
    #: Number of independent train/test splits in strict mode.
    n_repeats: int = 10
    #: Whether to report a paired Wilcoxon signed-rank test across repeats.
    paired_test: bool = True
    test_alpha: float = 0.05
    #: Which augmentation the statistics compare against the unaugmented model.
    reference_bucket: str = "before"


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #
@dataclass
class OutputConfig:
    outdir: str = "results"
    save_predictions: bool = True
    save_models: bool = False
    save_datasets: bool = True
    #: Emit CSV only (True) or CSV plus XLSX (False). CSV is preferred for
    #: version control; XLSX is kept for convenience.
    csv_only: bool = False
    dpi: int = 150


# --------------------------------------------------------------------------- #
# Root
# --------------------------------------------------------------------------- #
@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    gan: GanConfig = field(default_factory=GanConfig)
    models: List[ModelConfig] = field(default_factory=list)
    tuning: TuningConfig = field(default_factory=TuningConfig)
    evaluation: EvalConfig = field(default_factory=EvalConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    #: Extra CAI-style bookkeeping written into results metadata.
    notes: str = ""

    # -- helpers ----------------------------------------------------------- #
    def resolve_paths(self, base: Optional[Path] = None) -> "Config":
        """Make ``data.path`` and ``output.outdir`` absolute.

        Relative paths are resolved against ``base`` (the directory holding the
        YAML file) so that runs are independent of the current working
        directory.
        """
        base = Path.cwd() if base is None else Path(base)
        if not Path(self.data.path).is_absolute():
            self.data.path = str((base / self.data.path).resolve())
        if not Path(self.output.outdir).is_absolute():
            self.output.outdir = str((base / self.output.outdir).resolve())
        return self


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def _build(dc_type, values: Dict[str, Any]):
    """Instantiate a dataclass, rejecting unknown keys.

    Silently ignoring a typo in a YAML key is how a two-hour run ends up using
    the default value, so unknown keys are an error.
    """
    known = {f.name for f in dataclasses.fields(dc_type)}
    unknown = set(values) - known
    if unknown:
        raise ValueError(
            f"Unknown configuration key(s) for {dc_type.__name__}: {sorted(unknown)}. "
            f"Valid keys are: {sorted(known)}"
        )
    return dc_type(**values)


def config_from_dict(raw: Dict[str, Any]) -> Config:
    """Build a :class:`Config` from a nested dictionary."""
    raw = dict(raw or {})
    model_entries = raw.pop("models", []) or []

    explicit = {k: raw.pop(k) for k in ("data", "gan", "tuning", "evaluation", "output") if k in raw}
    notes = raw.pop("notes", "")
    if raw:
        raise ValueError(f"Unknown top-level configuration key(s): {sorted(raw)}")

    cfg = Config(
        data=_build(DataConfig, explicit.pop("data", {})),
        gan=_build(GanConfig, explicit.pop("gan", {})),
        tuning=_build(TuningConfig, explicit.pop("tuning", {})),
        evaluation=_build(EvalConfig, explicit.pop("evaluation", {})),
        output=_build(OutputConfig, explicit.pop("output", {})),
        notes=notes,
    )
    cfg.models = [_build(ModelConfig, m) for m in model_entries]
    return cfg


def load_config(path: Union[str, Path], overrides: Optional[Dict[str, Any]] = None) -> Config:
    """Load a YAML configuration file.

    Relative ``data.path`` and ``output.outdir`` entries are resolved against
    the YAML file's own directory, which keeps the repository relocatable.
    """
    path = Path(path).resolve()
    with open(path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    cfg = config_from_dict(raw)
    if overrides:
        cfg = apply_overrides(cfg, overrides)
    return cfg.resolve_paths(base=path.parent)


def apply_overrides(cfg: Config, overrides: Dict[str, Any]) -> Config:
    """Apply dotted-key overrides such as ``{"evaluation.n_repeats": 3}``."""
    for key, value in overrides.items():
        if value is None:
            continue
        parts = key.split(".")
        target: Any = cfg
        for part in parts[:-1]:
            if not hasattr(target, part):
                raise ValueError(f"Cannot override unknown setting {key!r}")
            target = getattr(target, part)
        leaf = parts[-1]
        if not hasattr(target, leaf):
            raise ValueError(f"Cannot override unknown setting {key!r}")
        setattr(target, leaf, value)
    return cfg


def n_candidates(mcfg: "ModelConfig") -> int:
    """Number of distinct hyperparameter combinations a model's grid implies.

    Counted as the cartesian product of each grid entry's list-valued fields,
    summed over entries. This is what ``validate_config`` uses to decide
    whether a model is actually being tuned, rather than counting how many
    top-level grid entries were written.
    """
    total = 0
    for entry in mcfg.param_grid or [{}]:
        size = 1
        for value in entry.values():
            size *= len(value) if isinstance(value, (list, tuple)) else 1
        total += size
    return max(total, 1)


def validate_config(cfg: Config) -> None:
    """Check the constraints that would otherwise fail deep inside a run."""
    problems: List[str] = []

    if cfg.data.test_size <= 0 or cfg.data.test_size >= 1:
        problems.append("data.test_size must lie strictly between 0 and 1")
    if not cfg.data.feature_columns:
        problems.append("data.feature_columns must not be empty")

    if cfg.gan.epochs < 1:
        problems.append("gan.epochs must be >= 1")
    if cfg.gan.z_dim < 1:
        problems.append("gan.z_dim must be >= 1")
    if cfg.gan.ratio <= 0:
        problems.append("gan.ratio must be positive")
    if cfg.gan.constraint_mode not in {"conditional", "mixture"}:
        problems.append("gan.constraint_mode must be 'conditional' or 'mixture'")
    if cfg.gan.constraint_mode == "mixture" and not cfg.gan.mixture_coefficients:
        problems.append("gan.constraint_mode='mixture' requires gan.mixture_coefficients")
    if cfg.evaluation.mode == "strict" and cfg.gan.pool_factor <= 1.0:
        problems.append(
            "gan.pool_factor must exceed 1.0 in strict mode, otherwise "
            "discriminator-based sample selection keeps the entire pool and has no effect"
        )
    if cfg.evaluation.mode not in {"strict", "legacy"}:
        problems.append("evaluation.mode must be 'strict' or 'legacy'")

    tuned = [m.name for m in cfg.models if m.enabled and n_candidates(m) > 1]
    if cfg.evaluation.mode == "strict" and not tuned:
        problems.append(
            "strict mode requires at least one model with a multi-candidate param_grid, "
            "so that tuning is applied symmetrically across buckets"
        )
    if len({m.name for m in cfg.models}) != len(cfg.models):
        problems.append("model names must be unique")
    if not any(m.enabled for m in cfg.models):
        problems.append("at least one model must be enabled")

    if problems:
        raise ValueError("Invalid configuration:\n  - " + "\n  - ".join(problems))
