"""Regression metrics and paired statistical comparison.

scikit-learn deprecated the ``squared`` keyword of ``mean_squared_error`` in
1.4 and removed it in 1.6, which broke the original script on any recent
install. Root mean squared error is therefore computed here as the square root
of ``mean_squared_error``, which works across versions.
"""

from __future__ import annotations

from typing import Dict, Sequence

import numpy as np
from scipy import stats
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

METRIC_KEYS = ("RMSE", "R2", "MAE")


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Return RMSE, R2 and MAE as plain floats."""
    y_true = np.asarray(y_true, dtype=float).ravel()
    y_pred = np.asarray(y_pred, dtype=float).ravel()
    if y_true.shape != y_pred.shape:
        raise ValueError(
            f"Shape mismatch: y_true has {y_true.shape[0]} rows, y_pred has {y_pred.shape[0]}"
        )
    mse = mean_squared_error(y_true, y_pred)
    return {
        "RMSE": float(np.sqrt(mse)),
        "R2": float(r2_score(y_true, y_pred)),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
    }


def paired_wilcoxon(a: Sequence[float], b: Sequence[float],
                    alpha: float = 0.05) -> Dict[str, float]:
    """Paired Wilcoxon signed-rank test of ``a`` against ``b``.

    Used to ask whether a difference between two augmentation strategies is
    larger than the variation across independent train/test splits. Returns
    NaN statistics when the two vectors are indistinguishable, which happens
    when a model is deterministic and the comparison is trivially identical.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    out = {"statistic": float("nan"), "p_value": float("nan"),
           "median_diff": float("nan"), "significant": float("nan")}
    if a.size != b.size or a.size < 2:
        return out
    diff = a - b
    out["median_diff"] = float(np.median(diff))
    if np.allclose(diff, 0.0):
        out["p_value"] = 1.0
        out["significant"] = 0.0
        return out
    try:
        # zero_method="zsplit" keeps the test defined when some repeats are ties
        res = stats.wilcoxon(a, b, zero_method="zsplit")
    except ValueError:
        return out
    out["statistic"] = float(res.statistic)
    out["p_value"] = float(res.pvalue)
    out["significant"] = float(res.pvalue < alpha)
    return out
