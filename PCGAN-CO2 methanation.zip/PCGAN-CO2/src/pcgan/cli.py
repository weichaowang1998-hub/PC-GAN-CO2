"""Command-line interface.

``pcgan-run --config config/default.yaml``
``pcgan-run --config config/default.yaml --mode legacy --outdir results/legacy``
``pcgan-run --config config/default.yaml --repeats 3 --device cpu --dry-run``
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from . import __version__
from .config import load_config, validate_config
from .data import load_dataset


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pcgan-run",
        description="Physics-constrained GAN augmentation for small-sample regression.",
    )
    p.add_argument("--config", type=str, default=None,
                   help="Path to a YAML configuration (default: config/default.yaml)")
    p.add_argument("--data", type=str, default=None,
                   help="Override data.path")
    p.add_argument("--outdir", type=str, default=None,
                   help="Override output.outdir")
    p.add_argument("--mode", choices=["strict", "legacy"], default=None,
                   help="strict = corrected methodology (default); "
                        "legacy = reproduce the original script's numbers")
    p.add_argument("--repeats", type=int, default=None,
                   help="Override evaluation.n_repeats (strict mode)")
    p.add_argument("--seed", type=int, default=None,
                   help="Override data.random_state")
    p.add_argument("--epochs", type=int, default=None,
                   help="Override gan.epochs")
    p.add_argument("--device", type=str, default=None,
                   help="Torch device, e.g. cpu or cuda")
    p.add_argument("--dry-run", action="store_true",
                   help="Validate the configuration and data layout, then exit")
    p.add_argument("--version", action="version", version=f"pcgan-co2 {__version__}")
    return p


def _default_config_path() -> Path:
    """``config/default.yaml`` relative to the installed package or the repo."""
    here = Path(__file__).resolve()
    candidates = [
        here.parents[2] / "config" / "default.yaml",   # src/pcgan/cli.py -> repo root
        Path.cwd() / "config" / "default.yaml",
    ]
    for c in candidates:
        if c.exists():
            return c
    return candidates[0]


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    cfg_path = Path(args.config) if args.config else _default_config_path()
    if not cfg_path.exists():
        print(f"error: configuration file not found: {cfg_path}", file=sys.stderr)
        print("Pass --config pointing at a YAML file (see config/default.yaml).",
              file=sys.stderr)
        return 2

    overrides = {}
    # Paths given on the command line are relative to the shell's working
    # directory, not to the YAML file, so they are absolutised before they
    # reach load_config (which resolves relative entries against the config).
    if args.data:
        overrides["data.path"] = str(Path(args.data).expanduser().resolve())
    if args.outdir:
        overrides["output.outdir"] = str(Path(args.outdir).expanduser().resolve())
    if args.mode:
        overrides["evaluation.mode"] = args.mode
    if args.repeats is not None:
        overrides["evaluation.n_repeats"] = args.repeats
    if args.seed is not None:
        overrides["data.random_state"] = args.seed
    if args.epochs is not None:
        overrides["gan.epochs"] = args.epochs

    try:
        cfg = load_config(cfg_path, overrides)
        validate_config(cfg)
    except (ValueError, KeyError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.dry_run:
        print("Configuration is valid.")
        print(f"  config : {cfg_path}")
        print(f"  mode   : {cfg.evaluation.mode}")
        print(f"  data   : {cfg.data.path}")
        print(f"  outdir : {cfg.output.outdir}")
        try:
            ds = load_dataset(cfg.data)
        except (ValueError, KeyError, OSError) as exc:
            print(f"Data check failed: {exc}", file=sys.stderr)
            return 2
        print(f"  samples: {ds.n_samples}  features: {ds.n_features}  "
              f"phys: {len(ds.phys_names)}")
        return 0

    from .runner import run

    try:
        run(cfg, device=args.device)
    except (ValueError, KeyError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
