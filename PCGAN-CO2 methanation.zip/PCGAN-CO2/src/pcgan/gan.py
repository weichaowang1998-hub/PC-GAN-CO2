"""Vanilla and physics-constrained GANs, plus discriminator-based selection.

Two departures from the original implementation are worth calling out because
they change what the code actually does:

1. **Selection is no longer a no-op.** Previously the candidate pool was
   exactly the number of samples kept, so ``argsort`` over the discriminator
   scores kept every sample and the scores had no effect. The pool is now
   ``pool_factor`` times larger than what is kept, and the top-scoring fraction
   is selected; ``validate_config`` rejects a ``pool_factor`` of 1.0 in strict
   mode so the regression cannot come back silently.

2. **The physical constraint is configurable.** In ``"conditional"`` mode the
   generator is pushed to reproduce the conditioning vector it was given, which
   is the behaviour of the original script: the penalty constrains the output
   columns to match their own inputs and does not encode a physical law. In
   ``"mixture"`` mode an additional penalty enforces a linear mixture rule
   across the physical block, which is a genuine constraint on the outputs.
   The mode is recorded in the results metadata so the paper can describe it
   accurately.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from torch import Tensor

from .config import GanConfig


# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
def set_global_seed(seed: int, deterministic_torch: bool = True) -> None:
    """Seed every RNG the pipeline touches.

    torch's cuDNN kernels are non-deterministic by default, so two runs on the
    same GPU with the same seed produce different synthetic samples unless the
    deterministic flags are set. ``use_deterministic_algorithms`` would be
    stricter still but can raise on some ops, so the flags are applied and the
    result is honest about being "reproducible in practice".
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic_torch:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def resolve_device(prefer: Optional[str] = None) -> torch.device:
    if prefer:
        return torch.device(prefer)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


# --------------------------------------------------------------------------- #
# Networks
# --------------------------------------------------------------------------- #
class Generator(nn.Module):
    """MLP mapping a latent vector to a full synthetic record."""

    def __init__(self, z_dim: int, out_dim: int, hidden: Tuple[int, ...] = (128, 256)):
        super().__init__()
        layers = []
        prev = z_dim
        for width in hidden:
            layers += [nn.Linear(prev, width), nn.LeakyReLU(0.2, inplace=True)]
            prev = width
        layers += [nn.Linear(prev, out_dim), nn.Tanh()]
        self.net = nn.Sequential(*layers)

    def forward(self, z: Tensor) -> Tensor:
        return self.net(z)


class Discriminator(nn.Module):
    """MLP scoring a record as real (1) or synthetic (0)."""

    def __init__(self, in_dim: int, hidden: Tuple[int, ...] = (256, 128)):
        super().__init__()
        layers = []
        prev = in_dim
        for width in hidden:
            layers += [nn.Linear(prev, width), nn.LeakyReLU(0.2, inplace=True)]
            prev = width
        layers += [nn.Linear(prev, 1), nn.Sigmoid()]
        self.net = nn.Sequential(*layers)

    def forward(self, x: Tensor) -> Tensor:
        return self.net(x).view(-1)


# --------------------------------------------------------------------------- #
# Fitted GAN
# --------------------------------------------------------------------------- #
@dataclass
class GanFit:
    """A trained GAN together with the scaler needed to invert its output."""

    generator: Generator
    discriminator: Discriminator
    scaler: MinMaxScaler
    n_features: int          # width of the generated record (X + y [+ phys])
    n_phys: int
    cfg: GanConfig
    device: torch.device
    history: dict
    embed: Optional[nn.Module] = None

    def sample(self, n: int, phys: Optional[np.ndarray] = None,
               seed: Optional[int] = None) -> np.ndarray:
        """Draw ``n`` records in the original (unscaled) units.

        Layout is ``[features..., target, phys...]``. When the GAN was
        conditioned on physical quantities, ``phys`` supplies the conditioning
        values; each generated row reuses the corresponding conditioning row.
        """
        if n <= 0:
            raise ValueError("n must be positive")
        # Draw on CPU so the explicit generator is portable across devices,
        # then move: torch.Generator(device="cuda") is not supported everywhere.
        gen = torch.Generator(device="cpu").manual_seed(
            int(seed if seed is not None else np.random.randint(0, 2**31 - 1))
        )
        self.generator.eval()
        with torch.no_grad():
            z = torch.randn(n, self.cfg.z_dim, generator=gen).to(self.device)
            if self.n_phys > 0 and self.cfg.constraint_mode in {"conditional", "mixture"}:
                if phys is None:
                    raise ValueError(
                        "This GAN was conditioned on physical quantities; "
                        "the conditioning array 'phys' is required for sampling"
                    )
                phys = np.asarray(phys, dtype=np.float32)
                if phys.shape[0] != n:
                    raise ValueError(
                        f"physics array has {phys.shape[0]} rows but {n} samples were requested"
                    )
                if phys.shape[1] != self.n_phys:
                    raise ValueError(
                        f"physics array has {phys.shape[1]} columns, expected {self.n_phys}"
                    )
                if self.embed is None:
                    raise RuntimeError(
                        "GAN was trained with conditioning but has no embedding layer"
                    )
                cond = torch.tensor(phys, dtype=torch.float32, device=self.device)
                z = z + self.embed(cond)
            out = self.generator(z).cpu().numpy()
        return self.scaler.inverse_transform(out)

    def score(self, records_scaled: np.ndarray) -> np.ndarray:
        """Discriminator score for already-scaled records in [-1, 1]."""
        self.discriminator.eval()
        with torch.no_grad():
            t = torch.tensor(records_scaled, dtype=torch.float32, device=self.device)
            return self.discriminator(t).cpu().numpy().ravel()


def _make_embedder(n_phys: int, z_dim: int, device: torch.device) -> nn.Module:
    """Zero-initialised linear conditioning map.

    Starting at zero means the first generator step is exactly the
    unconditional one, which keeps early training stable.
    """
    layer = nn.Linear(n_phys, z_dim).to(device)
    nn.init.zeros_(layer.weight)
    nn.init.zeros_(layer.bias)
    return layer


# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #
def train_gan(
    data_scaled: np.ndarray,
    cfg: GanConfig,
    n_phys: int,
    device: torch.device,
    seed: int,
    conditioned: bool,
    label: str = "GAN",
) -> GanFit:
    """Train a GAN on already-scaled records laid out ``[features, target, phys]``.

    Parameters
    ----------
    data_scaled:
        Real training records in ``[-1, 1]``, as produced by ``MinMaxScaler``.
    n_phys:
        Width of the trailing physical block. ``0`` gives the unconditional
        (vanilla) GAN.
    conditioned:
        Whether the generator receives the physical block as conditioning.
        Ignored when ``n_phys == 0``.
    """
    set_global_seed(seed)
    data_scaled = np.asarray(data_scaled, dtype=np.float32)
    n, dim = data_scaled.shape

    G = Generator(cfg.z_dim, dim, tuple(cfg.hidden_g)).to(device)
    D = Discriminator(dim, tuple(cfg.hidden_d)).to(device)
    use_cond = conditioned and n_phys > 0
    embed = _make_embedder(n_phys, cfg.z_dim, device) if use_cond else None

    params_g = list(G.parameters()) + (list(embed.parameters()) if embed else [])
    opt_g = optim.Adam(params_g, lr=cfg.lr_g, betas=(cfg.beta1, cfg.beta2))
    opt_d = optim.Adam(D.parameters(), lr=cfg.lr_d, betas=(cfg.beta1, cfg.beta2))
    bce = nn.BCELoss()
    mse = nn.MSELoss()

    dataset = torch.tensor(data_scaled, dtype=torch.float32)
    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=min(cfg.batch_size, n),
        shuffle=True,
        drop_last=False,   # dropping the remainder loses signal when n is small
        generator=torch.Generator().manual_seed(seed),
    )

    hist = {"d_loss": [], "g_loss": [], "phys_loss": []}
    G.train()
    D.train()
    if embed is not None:
        embed.train()

    for epoch in range(1, cfg.epochs + 1):
        d_sum = g_sum = p_sum = 0.0
        batches = 0
        for batch in loader:
            batch = batch.to(device)
            bs = batch.size(0)
            cond = batch[:, -n_phys:] if use_cond else None

            # ---- discriminator ----
            opt_d.zero_grad(set_to_none=True)
            real_lbl = torch.full((bs,), cfg.real_label, device=device)
            fake_lbl = torch.zeros(bs, device=device)
            d_real = bce(D(batch), real_lbl)
            z = torch.randn(bs, cfg.z_dim, device=device)
            z_in = z + embed(cond) if use_cond else z
            fake = G(z_in)
            d_fake = bce(D(fake.detach()), fake_lbl)
            d_loss = d_real + d_fake
            d_loss.backward()
            opt_d.step()

            # ---- generator ----
            opt_g.zero_grad(set_to_none=True)
            adv = bce(D(fake), torch.ones(bs, device=device))
            if use_cond:
                gen_cond = fake[:, -n_phys:]
                if cfg.constraint_mode == "mixture" and cfg.mixture_coefficients:
                    w = torch.tensor(cfg.mixture_coefficients, dtype=torch.float32, device=device)
                    if w.numel() != gen_cond.size(1):
                        raise ValueError(
                            f"mixture_coefficients has {w.numel()} entries but there are "
                            f"{gen_cond.size(1)} physical columns"
                        )
                    # Linear mixture rule: sum_j w_j * c_j should be constant,
                    # so its row-wise variance across the batch is the violation.
                    proj = gen_cond @ w
                    phys_loss = proj.var(unbiased=False)
                else:
                    phys_loss = mse(gen_cond, cond)
                g_loss = adv + cfg.lambda_phys * phys_loss
            else:
                phys_loss = torch.zeros((), device=device)
                g_loss = adv
            g_loss.backward()
            opt_g.step()

            d_sum += float(d_loss.item())
            g_sum += float(adv.item())
            p_sum += float(phys_loss.item())
            batches += 1

        hist["d_loss"].append(d_sum / max(batches, 1))
        hist["g_loss"].append(g_sum / max(batches, 1))
        hist["phys_loss"].append(p_sum / max(batches, 1))

        if cfg.verbose_every and (epoch % cfg.verbose_every == 0 or epoch <= 3):
            print(
                f"[{label}] epoch {epoch}/{cfg.epochs} | "
                f"D={hist['d_loss'][-1]:.4f} G={hist['g_loss'][-1]:.4f} "
                f"phys={hist['phys_loss'][-1]:.6f}"
            )

    G.eval()
    D.eval()
    fit = GanFit(
        generator=G, discriminator=D, scaler=MinMaxScaler(),  # scaler replaced below
        n_features=dim, n_phys=n_phys, cfg=cfg, device=device, history=hist,
        embed=embed,
    )
    return fit


def fit_gan_on(
    records: np.ndarray,
    cfg: GanConfig,
    n_phys: int,
    device: torch.device,
    seed: int,
    conditioned: bool,
    label: str = "GAN",
) -> GanFit:
    """Scale ``records`` to [-1, 1], train, and return a fitted GAN."""
    scaler = MinMaxScaler(feature_range=(-1, 1)).fit(records)
    scaled = scaler.transform(records).astype(np.float32)
    fit = train_gan(scaled, cfg, n_phys, device, seed, conditioned, label=label)
    fit.scaler = scaler
    return fit


# --------------------------------------------------------------------------- #
# Selection
# --------------------------------------------------------------------------- #
def select_samples(
    fit: GanFit,
    pool_size: int,
    keep: int,
    phys_pool: Optional[np.ndarray] = None,
    seed: Optional[int] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Generate a candidate pool and keep the ``keep`` most realistic records.

    The discriminator's score is used as a realism proxy: records that fool it
    most completely are the ones that best match the real training
    distribution. ``pool_size`` must exceed ``keep`` for this to do anything,
    which :func:`pcgan.config.validate_config` enforces in strict mode.

    Returns
    -------
    (records_raw, scores)
        ``records_raw`` has shape ``(keep, n_features)`` in original units,
        laid out ``[features, target, phys]``.
    """
    if keep < 1:
        raise ValueError("keep must be >= 1")
    if pool_size < keep:
        raise ValueError(
            f"pool_size ({pool_size}) must be >= keep ({keep}); selection would otherwise drop samples"
        )

    raw = fit.sample(pool_size, phys=phys_pool, seed=seed)
    scaled = fit.scaler.transform(raw).astype(np.float32)
    scores = fit.score(scaled)
    keep_idx = np.argsort(-scores)[:keep]
    return raw[keep_idx], scores[keep_idx]
