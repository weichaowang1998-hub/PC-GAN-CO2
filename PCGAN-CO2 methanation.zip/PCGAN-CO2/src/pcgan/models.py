"""Model factory and cross-validated hyperparameter search.

Every model is expressed as a scikit-learn compatible estimator so that the
same search and CV code applies to all of them, on all three data buckets. The
original script tuned the augmented models but left the baselines on hand-picked
constants, which confounded augmentation effects with tuning effects; a single
factory removes that asymmetry by construction.

Nested naming: estimators are built as a ``Pipeline`` with a response
transformer wrapped around it (``TransformedTargetRegressor``), so search
parameters are prefixed ``regressor__`` and ``regressor__model__``. Use
:func:`expand_params` to build those prefixed keys.
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
from sklearn.compose import TransformedTargetRegressor
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import ParameterGrid
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


# --------------------------------------------------------------------------- #
# Estimator construction
# --------------------------------------------------------------------------- #
def _require(name: str):
    try:
        if name == "lightgbm":
            import lightgbm
            return lightgbm
        if name == "xgboost":
            import xgboost
            return xgboost
    except ImportError as exc:  # pragma: no cover - dependency guard
        raise ImportError(
            f"The {name} backend is not installed. "
            f"Install it with: pip install {name}"
        ) from exc
    raise KeyError(name)


#: Models that need scaling are wrapped in a StandardScaler pipeline; the
#: gradient-boosted trees do not, and are fitted on raw features.
_SCALED = {"knn", "kernelridge", "svr", "mlp"}


def build_estimator(name: str, params: Dict[str, Any], seed: int):
    """Instantiate one estimator by registry name with ``params`` merged in."""
    p = dict(params)
    seed = int(seed)
    if name == "knn":
        return KNeighborsRegressor(**p)
    if name == "kernelridge":
        p.setdefault("kernel", "rbf")
        return KernelRidge(**p)
    if name == "svr":
        return SVR(**p)
    if name == "mlp":
        p.setdefault("max_iter", 2000)
        p.setdefault("early_stopping", True)
        p.setdefault("n_iter_no_change", 20)
        p.setdefault("random_state", seed)
        return MLPRegressor(**p)
    if name == "lightgbm":
        lgbm = _require("lightgbm")
        p.setdefault("objective", "regression")
        p.setdefault("random_state", seed)
        p.setdefault("n_jobs", 1)      # outer CV already parallelises
        p.setdefault("verbosity", -1)
        return lgbm.LGBMRegressor(**p)
    if name == "xgboost":
        xgb = _require("xgboost")
        p.setdefault("objective", "reg:squarederror")
        p.setdefault("random_state", seed)
        p.setdefault("n_jobs", 1)
        return xgb.XGBRegressor(**p)
    raise ValueError(
        f"Unknown model {name!r}. Available: knn, kernelridge, svr, mlp, lightgbm, xgboost"
    )


def build_pipeline(name: str, params: Dict[str, Any], seed: int,
                   scale_target: bool = True):
    """Return ``TransformedTargetRegressor(Pipeline[...])`` for ``name``.

    Response scaling is applied whenever the estimator is distance- or
    kernel-based, since their regularisation is defined in target units.
    Trees ignore it, so it is skipped to avoid an extra transform.
    """
    core = build_estimator(name, params, seed)
    if name in _SCALED:
        est = Pipeline([("scaler", StandardScaler()), ("model", core)])
    else:
        est = Pipeline([("model", core)])

    use_ttr = scale_target and name in {"kernelridge", "svr", "mlp"}
    if use_ttr:
        wrapped = TransformedTargetRegressor(regressor=est, transformer=StandardScaler())
        prefix = "regressor__model__"
    else:
        wrapped = est
        prefix = "model__"
    return wrapped, prefix


def expand_params(name: str, grid_entry: Dict[str, Any], fixed: Dict[str, Any] | None = None,
                  seed: int = 0) -> List[Dict[str, Any]]:
    """Expand a ``param_grid`` entry into prefixed, ready-to-search dicts.

    Keys in a grid entry name the estimator's own arguments (``C``, ``alpha``,
    ``n_estimators``); prefixes are added here so the YAML stays readable.
    """
    fixed = dict(fixed or {})
    _, prefix = build_pipeline(name, {}, seed)
    # ParameterGrid requires every value to be a sequence. Grids written by
    # hand (and the legacy grids in legacy.py) often set a parameter to a
    # single scalar, so scalars are wrapped into a one-element list here.
    normalised: Dict[str, Any] = {}
    for key, value in (grid_entry or {}).items():
        normalised[key] = value if isinstance(value, (list, tuple, np.ndarray)) else [value]

    out: List[Dict[str, Any]] = []
    for combo in ParameterGrid(normalised or {}):
        merged = {**fixed, **combo}
        out.append({f"{prefix}{k}": v for k, v in merged.items()})
    return out


def default_param_grid(name: str) -> List[Dict[str, Any]]:
    """Compact default grid, small enough to stay honest on tiny datasets."""
    grids = {
        "knn": [{"n_neighbors": [3, 4, 5, 6, 8], "weights": ["uniform", "distance"],
                 "p": [1, 2]}],
        "kernelridge": [{"alpha": [1e-3, 1e-2, 1e-1, 1.0], "gamma": [0.01, 0.05, 0.1, 0.5]}],
        "svr": [{"C": [0.1, 1.0, 10.0], "epsilon": [0.01, 0.05, 0.1],
                 "kernel": ["rbf"], "gamma": ["scale"]}],
        "mlp": [{"hidden_layer_sizes": [(64,), (128, 64), (256, 128, 64)],
                 "alpha": [1e-5, 1e-3]}],
        "lightgbm": [{"n_estimators": [300, 600], "learning_rate": [0.03, 0.05],
                      "num_leaves": [15, 31], "min_child_samples": [5, 10],
                      "reg_lambda": [1.0, 3.0], "feature_fraction": [0.8],
                      "bagging_fraction": [0.8], "bagging_freq": [1]}],
        "xgboost": [{"n_estimators": [300, 600], "learning_rate": [0.01, 0.03],
                     "max_depth": [4, 6], "min_child_weight": [1, 3],
                     "subsample": [0.9], "colsample_bytree": [0.9],
                     "reg_lambda": [1.0, 3.0]}],
    }
    if name not in grids:
        raise ValueError(f"No default parameter grid for {name!r}")
    return grids[name]
