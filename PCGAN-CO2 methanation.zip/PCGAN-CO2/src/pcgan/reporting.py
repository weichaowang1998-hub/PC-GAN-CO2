"""Aggregation across repeats, tabular export and figures.

Outputs are deliberately plain: CSVs of per-run metrics and of per-model
predictions, a JSON of selected hyperparameters, PNG figures. Everything is
written under ``output.outdir`` so a single directory can be archived with the
paper.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from .config import Config
from .metrics import METRIC_KEYS, paired_wilcoxon
from .pipeline import SplitResult


# --------------------------------------------------------------------------- #
# Aggregation
# --------------------------------------------------------------------------- #
def aggregate(results: Sequence[SplitResult]) -> pd.DataFrame:
    """Mean and standard deviation of each metric per (model, bucket)."""
    rows: List[dict] = []
    for sr in results:
        rows.extend(sr.flat_rows())
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    keys = ["model", "bucket"]
    grouped = df.groupby(keys, sort=False)

    summary = grouped.agg(
        RMSE_mean=("RMSE", "mean"), RMSE_std=("RMSE", "std"),
        R2_mean=("R2", "mean"), R2_std=("R2", "std"),
        MAE_mean=("MAE", "mean"), MAE_std=("MAE", "std"),
        cv_rmse_mean=("cv_rmse", "mean"),
        n_train_mean=("n_train", "mean"),
        n_repeats=("RMSE", "size"),
    ).reset_index()

    # Single-split runs leave ``std`` as NaN; report 0 rather than blank so the
    # table remains numerically parseable.
    for col in ("RMSE_std", "R2_std", "MAE_std"):
        summary[col] = summary[col].fillna(0.0)

    bucket_order = {b: i for i, b in enumerate(("before", "after", "after_pc"))}
    summary["_bo"] = summary["bucket"].map(bucket_order).fillna(99)
    summary = summary.sort_values(["model", "_bo"]).drop(columns="_bo").reset_index(drop=True)
    return summary


def wide_summary(summary: pd.DataFrame) -> pd.DataFrame:
    """Pivot to one row per model with before/after/after_pc columns."""
    if summary.empty:
        return summary
    metrics = ["RMSE_mean", "R2_mean", "MAE_mean", "RMSE_std", "R2_std"]
    wide = summary.pivot(index="model", columns="bucket", values=metrics)
    wide.columns = [f"{metric}_{bucket}" for metric, bucket in wide.columns]
    return wide.reset_index()


def delta_table(summary: pd.DataFrame, reference: str = "before") -> pd.DataFrame:
    """Relative change in RMSE/R2/MAE of each bucket against ``reference``.

    A negative RMSE delta means the augmentation helped.
    """
    if summary.empty:
        return summary
    wide = wide_summary(summary)
    rows = []
    for _, row in wide.iterrows():
        entry = {"model": row["model"]}
        for bucket in ("after", "after_pc"):
            for metric in METRIC_KEYS:
                base = row.get(f"{metric}_mean_{reference}")
                cand = row.get(f"{metric}_mean_{bucket}")
                if base is None or cand is None or not np.isfinite(base) or np.isclose(base, 0.0):
                    entry[f"{metric}_delta_{bucket}"] = np.nan
                else:
                    entry[f"{metric}_delta_{bucket}"] = float((cand - base) / abs(base))
        rows.append(entry)
    return pd.DataFrame(rows)


def significance_table(results: Sequence[SplitResult], cfg: Config) -> pd.DataFrame:
    """Paired Wilcoxon test per model: each bucket against the reference bucket.

    Requires more than one repeat; with a single split there is nothing to
    pair and the table is empty.
    """
    if len(results) < 2:
        return pd.DataFrame()

    rows = []
    models = sorted({m for sr in results for m in sr.results})
    ref = cfg.evaluation.reference_bucket
    for model in models:
        for bucket in ("after", "after_pc"):
            a, b = [], []
            for sr in results:
                rb = sr.results.get(model, {}).get(bucket)
                rr = sr.results.get(model, {}).get(ref)
                if rb is None or rr is None:
                    continue
                a.append(rb.test["RMSE"])
                b.append(rr.test["RMSE"])
            if len(a) < 2:
                continue
            stat = paired_wilcoxon(a, b, alpha=cfg.evaluation.test_alpha)
            rows.append({
                "model": model,
                "comparison": f"{bucket} vs {ref}",
                "n_pairs": len(a),
                "median_RMSE_diff": stat["median_diff"],
                "wilcoxon_statistic": stat["statistic"],
                "p_value": stat["p_value"],
                "significant": stat["significant"],
                "alpha": cfg.evaluation.test_alpha,
            })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Export
# --------------------------------------------------------------------------- #
def _write_table(df: pd.DataFrame, path: Path, csv_only: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    if not csv_only:
        try:
            df.to_excel(path.with_suffix(".xlsx"), index=False)
        except ImportError:
            pass


def export_results(
    cfg: Config,
    results: Sequence[SplitResult],
    dataset,
    outdir: Path,
) -> Dict[str, pd.DataFrame]:
    """Write summary tables, predictions and hyperparameters; return the tables."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    csv_only = cfg.output.csv_only
    tables: Dict[str, pd.DataFrame] = {}

    per_run = pd.DataFrame([row for sr in results for row in sr.flat_rows()])
    tables["per_run"] = per_run
    if not per_run.empty:
        _write_table(per_run, outdir / "metrics_per_run.csv", csv_only)

    summary = aggregate(results)
    tables["summary"] = summary
    if not summary.empty:
        _write_table(summary, outdir / "metrics_summary.csv", csv_only)

        wide = wide_summary(summary)
        tables["wide"] = wide
        _write_table(wide, outdir / "metrics_summary_wide.csv", csv_only)

        deltas = delta_table(summary, cfg.evaluation.reference_bucket)
        tables["delta"] = deltas
        _write_table(deltas, outdir / "metrics_delta_vs_reference.csv", csv_only)

    if cfg.evaluation.paired_test:
        sig = significance_table(results, cfg)
        tables["significance"] = sig
        if not sig.empty:
            _write_table(sig, outdir / "statistical_tests.csv", csv_only)

    # Selected hyperparameters, one row per (repeat, model, bucket).
    param_rows = []
    for sr in results:
        for model, buckets in sr.results.items():
            for bucket, r in buckets.items():
                param_rows.append({
                    "repeat": sr.repeat,
                    "split_seed": sr.seed,
                    "model": model,
                    "bucket": bucket,
                    "selected_params": json.dumps(r.params, sort_keys=True, default=str),
                    "cv_rmse": r.cv_rmse,
                })
    if param_rows:
        params_df = pd.DataFrame(param_rows)
        tables["params"] = params_df
        _write_table(params_df, outdir / "selected_hyperparameters.csv", csv_only)

    if cfg.output.save_predictions:
        pred_frames = []
        for sr in results:
            if sr.test_labels is None:
                continue
            for model, buckets in sr.results.items():
                for bucket, r in buckets.items():
                    if r.y_pred is None:
                        continue
                    pred_frames.append(pd.DataFrame({
                        "repeat": sr.repeat,
                        "split_seed": sr.seed,
                        "model": model,
                        "bucket": bucket,
                        "sample_index": np.arange(len(r.y_pred)),
                        "y_true": sr.test_labels,
                        "y_pred": r.y_pred,
                        "residual": r.y_pred - sr.test_labels,
                    }))
        if pred_frames:
            preds = pd.concat(pred_frames, ignore_index=True)
            tables["predictions"] = preds
            _write_table(preds, outdir / "predictions.csv", csv_only)

    # Metadata describing exactly what produced these numbers.
    meta = {
        "mode": cfg.evaluation.mode,
        "n_repeats": cfg.evaluation.n_repeats,
        "n_samples_total": dataset.n_samples,
        "n_features": dataset.n_features,
        "feature_names": list(dataset.feature_names),
        "target_name": dataset.target_name,
        "phys_names": list(dataset.phys_names),
        "composition_columns": [dataset.feature_names[i] for i in dataset.composition_idx],
        "gan": asdict(cfg.gan),
        "tuning": asdict(cfg.tuning),
        "data_path": cfg.data.path,
        "notes": cfg.notes,
    }
    with open(outdir / "run_metadata.json", "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, default=str)

    return tables


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def plot_metric_comparison(summary: pd.DataFrame, metric: str, outdir: Path,
                           dpi: int = 150) -> Optional[Path]:
    """Grouped bar chart of one metric across buckets."""
    if summary.empty or f"{metric}_mean" not in summary.columns:
        return None

    import matplotlib
    matplotlib.use("Agg")           # never block on an interactive backend
    import matplotlib.pyplot as plt

    models = list(dict.fromkeys(summary["model"]))
    buckets = [b for b in ("before", "after", "after_pc") if b in set(summary["bucket"])]
    lookup = {(r["model"], r["bucket"]): r[f"{metric}_mean"] for _, r in summary.iterrows()}

    x = np.arange(len(models))
    width = 0.8 / max(len(buckets), 1)
    fig, ax = plt.subplots(figsize=(max(8, 1.6 * len(models)), 5))
    for i, bucket in enumerate(buckets):
        vals = [lookup.get((m, bucket), np.nan) for m in models]
        ax.bar(x + (i - (len(buckets) - 1) / 2) * width, vals, width, label=bucket)
    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=30, ha="right")
    ax.set_ylabel(metric)
    ax.set_title(f"{metric} by augmentation strategy")
    ax.legend(title="bucket")
    fig.tight_layout()

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / f"{metric.lower()}_by_bucket.png"
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
    return path


def plot_gan_training(history: Dict[str, List[float]], outdir: Path, label: str,
                      dpi: int = 150) -> Optional[Path]:
    """Loss curves for a single GAN fit."""
    if not history or not history.get("d_loss"):
        return None

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4))
    epochs = np.arange(1, len(history["d_loss"]) + 1)
    ax.plot(epochs, history["d_loss"], label="discriminator")
    ax.plot(epochs, history["g_loss"], label="generator (adversarial)")
    if any(history.get("phys_loss", [])):
        ax2 = ax.twinx()
        ax2.plot(epochs, history["phys_loss"], color="tab:green", alpha=0.6,
                 label="constraint penalty")
        ax2.set_ylabel("constraint penalty")
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    ax.set_title(f"{label} training")
    ax.legend(loc="upper right")
    fig.tight_layout()

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / f"gan_training_{label.replace(' ', '_').lower()}.png"
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
    return path
