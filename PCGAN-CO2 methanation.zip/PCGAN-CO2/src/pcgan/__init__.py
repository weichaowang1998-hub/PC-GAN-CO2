"""PC-GAN: physics-constrained GAN augmentation for small-sample regression.

Public entry points are :func:`pcgan.cli.main` and :func:`pcgan.runner.run`.
"""

from __future__ import annotations

__version__ = "1.0.0"

from .config import Config, GanConfig, ModelConfig, load_config, validate_config
from .data import Dataset, load_dataset

__all__ = [
    "__version__",
    "Config",
    "GanConfig",
    "ModelConfig",
    "load_config",
    "validate_config",
    "Dataset",
    "load_dataset",
]
