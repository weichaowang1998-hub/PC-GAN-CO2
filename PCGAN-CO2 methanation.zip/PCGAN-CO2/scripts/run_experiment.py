"""Run the experiment from a configuration file.

Thin wrapper around :func:`pcgan.cli.main` so the repository can be run without
installing the package:

    python scripts/run_experiment.py --config config/default.yaml
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running from a fresh clone: add src/ to the path.
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pcgan.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
