"""Generate a small synthetic dataset with the same layout as the real one.

Used by the test suite and useful for a fast smoke run without shipping the
real spreadsheet. The generated table has 11 columns:

    0-6  features (0-3 are compositions summing to 1)
    7    target
    8-10 physical quantities

Usage:
    python scripts/make_synthetic_data.py --out data/synthetic_demo.xlsx
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def make_table(n: int = 60, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    # Dirichlet compositions so the four fractions sum to one.
    comp = rng.dirichlet(alpha=[2.0, 1.5, 1.0, 1.0], size=n)
    other = rng.uniform(0.0, 1.0, size=(n, 3))

    phys = rng.normal(size=(n, 3))
    # Target depends on both blocks so that models can actually learn
    # something and the augmentation comparison is not pure noise.
    y = (
        2.0 * comp[:, 0]
        - 1.5 * comp[:, 1]
        + 0.8 * other[:, 0]
        + 0.5 * phys[:, 0]
        - 0.3 * phys[:, 1]
        + rng.normal(scale=0.05, size=n)
    )

    cols = [f"feature_{i}" for i in range(7)] + ["target"] + [f"phys_{i}" for i in range(3)]
    data = np.hstack([comp, other, y.reshape(-1, 1), phys])
    return pd.DataFrame(data, columns=cols)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=str, default="data/synthetic_demo.xlsx")
    p.add_argument("--n", type=int, default=60)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    df = make_table(args.n, args.seed)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.suffix.lower() == ".csv":
        df.to_csv(out, index=False)
    else:
        df.to_excel(out, index=False)
    print(f"wrote {len(df)} rows x {df.shape[1]} columns to {out}")


if __name__ == "__main__":
    main()
