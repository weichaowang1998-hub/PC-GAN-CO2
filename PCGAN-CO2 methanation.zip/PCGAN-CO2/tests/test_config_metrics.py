"""Tests for configuration validation, metrics and sample weights."""

from __future__ import annotations

import numpy as np
import pytest

from pcgan.config import (
    Config,
    EvalConfig,
    GanConfig,
    ModelConfig,
    config_from_dict,
    validate_config,
)
from pcgan.evaluation import build_sample_weight
from pcgan.metrics import paired_wilcoxon, regression_metrics


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
def _minimal(models=None, **overrides) -> Config:
    cfg = Config(
        models=models if models is not None else [
            ModelConfig(name="knn", param_grid=[{"n_neighbors": [3, 5]}])
        ],
        gan=GanConfig(epochs=2, pool_factor=2.0),
        evaluation=EvalConfig(mode="strict", n_repeats=1),
    )
    for key, value in overrides.items():
        setattr(cfg, key, value)
    return cfg


def test_valid_config_passes():
    validate_config(_minimal())


def test_pool_factor_of_one_is_rejected_in_strict_mode():
    """A pool of exactly the keep-count makes selection a no-op."""
    cfg = _minimal(gan=GanConfig(epochs=2, pool_factor=1.0))
    with pytest.raises(ValueError, match="pool_factor"):
        validate_config(cfg)


def test_pool_factor_of_one_is_allowed_in_legacy_mode():
    cfg = _minimal(gan=GanConfig(epochs=2, pool_factor=1.0),
                   evaluation=EvalConfig(mode="legacy", n_repeats=1))
    validate_config(cfg)


def test_strict_mode_requires_at_least_one_tunable_model():
    cfg = _minimal(models=[ModelConfig(name="knn", param_grid=[{}])])
    with pytest.raises(ValueError, match="param_grid"):
        validate_config(cfg)


def test_unknown_yaml_key_is_an_error():
    with pytest.raises(ValueError, match="Unknown configuration key"):
        config_from_dict({"gan": {"epochz": 10}})


def test_unknown_top_level_key_is_an_error():
    with pytest.raises(ValueError, match="Unknown top-level"):
        config_from_dict({"gann": {}})


def test_mixture_mode_requires_coefficients():
    cfg = _minimal(gan=GanConfig(epochs=2, pool_factor=2.0, constraint_mode="mixture"))
    with pytest.raises(ValueError, match="mixture_coefficients"):
        validate_config(cfg)


def test_bad_test_size_is_rejected():
    base = _minimal()
    base.data.test_size = 1.5
    with pytest.raises(ValueError, match="test_size"):
        validate_config(base)


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
def test_metrics_match_manual_computation():
    y_true = np.array([1.0, 2.0, 3.0])
    y_pred = np.array([1.0, 2.0, 4.0])
    m = regression_metrics(y_true, y_pred)
    assert m["RMSE"] == pytest.approx(np.sqrt(1.0 / 3.0))
    assert m["MAE"] == pytest.approx(1.0 / 3.0)
    assert m["R2"] < 1.0


def test_metrics_do_not_depend_on_removed_squared_argument():
    """RMSE must be computable on any scikit-learn version.

    The original script called ``mean_squared_error(..., squared=False)``,
    which raised TypeError once the keyword was removed in 1.6. This asserts
    the behaviour rather than the source text, so it keeps passing regardless
    of scikit-learn's version.
    """
    from sklearn.metrics import mean_squared_error

    y_true = np.array([1.0, 2.0, 3.0])
    y_pred = np.array([1.5, 2.0, 2.5])
    expected = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    assert regression_metrics(y_true, y_pred)["RMSE"] == pytest.approx(expected)


def test_metrics_shape_mismatch_raises():
    with pytest.raises(ValueError, match="Shape mismatch"):
        regression_metrics([1.0, 2.0], [1.0])


def test_paired_wilcoxon_identical_vectors_gives_p_one():
    out = paired_wilcoxon([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
    assert out["p_value"] == pytest.approx(1.0)
    assert out["significant"] == 0.0


def test_paired_wilcoxon_detects_consistent_difference():
    a = [0.10, 0.11, 0.12, 0.09, 0.10, 0.11]
    b = [0.20, 0.21, 0.22, 0.19, 0.20, 0.21]
    out = paired_wilcoxon(a, b)
    assert out["p_value"] < 0.05
    assert out["median_diff"] == pytest.approx(-0.10)


def test_paired_wilcoxon_single_pair_is_undefined():
    out = paired_wilcoxon([1.0], [2.0])
    assert np.isnan(out["p_value"])


# --------------------------------------------------------------------------- #
# Sample weights
# --------------------------------------------------------------------------- #
def test_unit_synth_weight_returns_none():
    """Claiming weighted training while weighting everything equally is a no-op."""
    assert build_sample_weight(n_real=10, n_total=20, synth_weight=1.0) is None


def test_weights_mark_real_and_synthetic_rows():
    w = build_sample_weight(n_real=4, n_total=6, synth_weight=0.5)
    assert w is not None
    assert np.allclose(w[:4], 1.0)
    assert np.allclose(w[4:], 0.5)


def test_no_synthetic_rows_returns_none():
    assert build_sample_weight(n_real=5, n_total=5, synth_weight=0.3) is None
