"""Tests for the GAN, selection behaviour and the end-to-end run."""

from __future__ import annotations

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from pcgan.config import GanConfig  # noqa: E402
from pcgan.gan import (  # noqa: E402
    Discriminator,
    Generator,
    fit_gan_on,
    select_samples,
    set_global_seed,
)


@pytest.fixture(scope="module")
def toy_records():
    rng = np.random.default_rng(0)
    return np.hstack([
        rng.dirichlet([2, 2, 1, 1], size=40),
        rng.uniform(size=(40, 1)),
        rng.normal(size=(40, 3)),
    ]).astype(np.float32)


def _cfg(**kw) -> GanConfig:
    return GanConfig(z_dim=8, epochs=3, batch_size=8, verbose_every=0,
                     hidden_g=(16, 16), hidden_d=(16, 16), **kw)


def test_generator_output_shape():
    g = Generator(z_dim=5, out_dim=11, hidden=(16, 32))
    out = g(torch.randn(7, 5))
    assert out.shape == (7, 11)
    assert torch.all(out.abs() <= 1.0)


def test_discriminator_output_is_probability_vector():
    d = Discriminator(in_dim=11, hidden=(16, 16))
    out = d(torch.randn(9, 11))
    assert out.shape == (9,)
    assert torch.all(out >= 0) and torch.all(out <= 1)


def test_fit_gan_returns_requested_width(toy_records):
    fit = fit_gan_on(toy_records, _cfg(), n_phys=0, device=torch.device("cpu"),
                     seed=0, conditioned=False)
    samples = fit.sample(12, seed=1)
    assert samples.shape == (12, toy_records.shape[1])


def test_conditioned_sample_requires_physics_input(toy_records):
    fit = fit_gan_on(toy_records, _cfg(), n_phys=3, device=torch.device("cpu"),
                     seed=0, conditioned=True)
    with pytest.raises(ValueError, match="conditioning array"):
        fit.sample(5)
    phys = np.zeros((5, 3), dtype=np.float32)
    assert fit.sample(5, phys=phys).shape == (5, toy_records.shape[1])


def test_conditioned_sample_validates_physics_width(toy_records):
    fit = fit_gan_on(toy_records, _cfg(), n_phys=3, device=torch.device("cpu"),
                     seed=0, conditioned=True)
    with pytest.raises(ValueError, match="columns"):
        fit.sample(5, phys=np.zeros((5, 2), dtype=np.float32))


def test_selection_actually_discards_when_pool_exceeds_keep(toy_records):
    """The original pool==keep bug made selection a no-op; this pins the fix."""
    fit = fit_gan_on(toy_records, _cfg(), n_phys=0, device=torch.device("cpu"),
                     seed=0, conditioned=False)
    raw, scores = select_samples(fit, pool_size=40, keep=5, seed=3)
    assert raw.shape[0] == 5
    assert scores.shape[0] == 5


def test_selection_keeps_highest_scores(toy_records):
    fit = fit_gan_on(toy_records, _cfg(), n_phys=0, device=torch.device("cpu"),
                     seed=0, conditioned=False)
    fit.generator.eval()
    raw_all = fit.sample(50, seed=11)
    all_scores = fit.score(fit.scaler.transform(raw_all).astype(np.float32))
    expected_top = np.max(all_scores)

    raw, scores = select_samples(fit, pool_size=50, keep=3, seed=11)
    # Re-drawing with the same seed gives an identical pool, so the top score
    # of the selection must match the top score of that pool.
    assert scores.max() <= expected_top + 1e-6


def test_selection_rejects_pool_smaller_than_keep(toy_records):
    fit = fit_gan_on(toy_records, _cfg(), n_phys=0, device=torch.device("cpu"),
                     seed=0, conditioned=False)
    with pytest.raises(ValueError, match="pool_size"):
        select_samples(fit, pool_size=3, keep=5)


def test_same_seed_gives_identical_samples(toy_records):
    cfg = _cfg()
    fit = fit_gan_on(toy_records, cfg, n_phys=0, device=torch.device("cpu"),
                     seed=5, conditioned=False)
    a = fit.sample(6, seed=99)
    b = fit.sample(6, seed=99)
    assert np.allclose(a, b)


def test_set_global_seed_repeats_torch_draws():
    set_global_seed(123)
    a = torch.randn(4)
    set_global_seed(123)
    b = torch.randn(4)
    assert torch.allclose(a, b)


# --------------------------------------------------------------------------- #
# End-to-end
# --------------------------------------------------------------------------- #
def test_end_to_end_run_writes_expected_files(fast_config, tmp_path):
    from pcgan.runner import run

    tables = run(fast_config)
    outdir = tmp_path / "results"

    assert "summary" in tables and not tables["summary"].empty
    for name in ("metrics_summary.csv", "metrics_per_run.csv",
                 "run_metadata.json", "environment.json"):
        assert (outdir / name).exists(), f"missing {name}"

    buckets = set(tables["summary"]["bucket"])
    assert {"before", "after", "after_pc"} <= buckets
    models = set(tables["summary"]["model"])
    assert models == {"knn", "kernelridge"}


def test_end_to_end_is_reproducible(fast_config, tmp_path):
    from pcgan.runner import run

    fast_config.output.outdir = str(tmp_path / "a")
    first = run(fast_config)
    fast_config.output.outdir = str(tmp_path / "b")
    second = run(fast_config)

    a = first["summary"].sort_values(["model", "bucket"]).reset_index(drop=True)
    b = second["summary"].sort_values(["model", "bucket"]).reset_index(drop=True)
    assert np.allclose(a["RMSE_mean"], b["RMSE_mean"])


def test_strict_mode_without_phys_columns_skips_pc_bucket(fast_config):
    from pcgan.runner import run

    fast_config.data.phys_columns = []
    tables = run(fast_config)
    assert "after_pc" not in set(tables["summary"]["bucket"])
    assert {"before", "after"} <= set(tables["summary"]["bucket"])


def test_legacy_mode_runs(fast_config):
    from pcgan.runner import run

    fast_config.evaluation.mode = "legacy"
    fast_config.gan.pool_factor = 1.0     # the original pool==keep behaviour
    tables = run(fast_config)
    assert not tables["summary"].empty
