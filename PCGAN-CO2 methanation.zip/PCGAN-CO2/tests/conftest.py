"""Shared pytest fixtures."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pcgan.config import (  # noqa: E402
    Config,
    DataConfig,
    EvalConfig,
    GanConfig,
    ModelConfig,
    OutputConfig,
    TuningConfig,
)


@pytest.fixture(scope="session")
def synthetic_frame() -> pd.DataFrame:
    """60-row table with the real spreadsheet's column layout."""
    rng = np.random.default_rng(7)
    n = 60
    comp = rng.dirichlet([2.0, 1.5, 1.0, 1.0], size=n)
    other = rng.uniform(size=(n, 3))
    phys = rng.normal(size=(n, 3))
    y = 2.0 * comp[:, 0] - 1.5 * comp[:, 1] + 0.8 * other[:, 0] + 0.5 * phys[:, 0]
    cols = [f"f{i}" for i in range(7)] + ["target"] + [f"p{i}" for i in range(3)]
    return pd.DataFrame(np.hstack([comp, other, y.reshape(-1, 1), phys]), columns=cols)


@pytest.fixture
def data_file(tmp_path, synthetic_frame) -> Path:
    path = tmp_path / "synthetic.csv"
    synthetic_frame.to_csv(path, index=False)
    return path


@pytest.fixture
def fast_config(data_file, tmp_path) -> Config:
    """A configuration small enough to run in a few seconds on CPU."""
    return Config(
        data=DataConfig(
            path=str(data_file),
            feature_columns=list(range(7)),
            target_column=7,
            phys_columns=[8, 9, 10],
            composition_columns=[0, 1, 2, 3],
            normalize_composition=True,
            test_size=0.25,
            random_state=42,
        ),
        gan=GanConfig(
            z_dim=8,
            hidden_g=(16, 32),
            hidden_d=(32, 16),
            epochs=6,
            batch_size=16,
            pool_factor=2.0,
            ratio=0.5,
            verbose_every=0,
        ),
        models=[
            ModelConfig(name="knn", param_grid=[{"n_neighbors": [3, 5]}]),
            ModelConfig(name="kernelridge", param_grid=[{"alpha": [0.01, 1.0]}]),
        ],
        tuning=TuningConfig(cv_folds=3, random_state=42),
        evaluation=EvalConfig(mode="strict", n_repeats=2, paired_test=True),
        output=OutputConfig(outdir=str(tmp_path / "results"), csv_only=True),
    )
