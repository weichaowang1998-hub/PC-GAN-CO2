"""Tests for composition handling, column resolution and data loading."""

from __future__ import annotations

import numpy as np
import pytest

from pcgan.config import DataConfig
from pcgan.data import (
    load_dataset,
    normalize_compositions,
    project_to_simplex,
    resolve_columns,
)


def test_normalize_compositions_makes_rows_sum_to_one():
    X = np.array([[2.0, 2.0, 0.0, 0.0, 9.0],
                  [1.0, 1.0, 1.0, 1.0, 3.0]])
    out = normalize_compositions(X, [0, 1, 2, 3])
    assert np.allclose(out[:, :4].sum(axis=1), 1.0)
    # Non-composition columns are untouched.
    assert np.allclose(out[:, 4], [9.0, 3.0])


def test_normalize_compositions_leaves_zero_rows_alone():
    X = np.array([[0.0, 0.0, 0.0, 0.0, 1.0]])
    out = normalize_compositions(X, [0, 1, 2, 3])
    assert np.allclose(out[0, :4], 0.0)


def test_project_to_simplex_clips_negatives_and_renormalises():
    X = np.array([[-0.2, 0.5, 0.4, 0.3]])
    out = project_to_simplex(X, [0, 1, 2, 3])
    assert np.all(out[:, :4] >= 0.0)
    assert np.allclose(out[:, :4].sum(axis=1), 1.0)


def test_project_to_simplex_handles_all_negative_row():
    X = np.array([[-1.0, -1.0, -1.0, -1.0]])
    out = project_to_simplex(X, [0, 1, 2, 3])
    assert np.allclose(out[:, :4], 0.25)


def test_resolve_columns_rejects_target_used_as_feature(synthetic_frame):
    cfg = DataConfig(feature_columns=[0, 1, 2, 3, 4, 5, 6], target_column=6,
                     phys_columns=[8, 9, 10], composition_columns=[0, 1])
    with pytest.raises(ValueError, match="also listed as a feature"):
        resolve_columns(synthetic_frame, cfg)


def test_resolve_columns_reports_out_of_range_index(synthetic_frame):
    cfg = DataConfig(feature_columns=[0, 1, 99], target_column=7)
    with pytest.raises(IndexError, match="out of range"):
        resolve_columns(synthetic_frame, cfg)


def test_resolve_columns_accepts_names(synthetic_frame):
    cfg = DataConfig(
        feature_columns=["f0", "f1", "f2", "f3"],
        target_column="target",
        phys_columns=["p0", "p1", "p2"],
        composition_columns=["f0", "f1"],
    )
    feats, target, phys, comp_idx = resolve_columns(synthetic_frame, cfg)
    assert target == "target"
    assert phys == ["p0", "p1", "p2"]
    assert comp_idx == [0, 1]


def test_load_dataset_normalises_compositions(data_file):
    cfg = DataConfig(
        path=str(data_file),
        feature_columns=list(range(7)),
        target_column=7,
        phys_columns=[8, 9, 10],
        composition_columns=[0, 1, 2, 3],
        normalize_composition=True,
    )
    ds = load_dataset(cfg)
    assert ds.n_samples == 60
    assert ds.has_phys
    assert np.allclose(ds.X[:, :4].sum(axis=1), 1.0)


def test_load_dataset_missing_file_has_actionable_message(tmp_path):
    cfg = DataConfig(path=str(tmp_path / "nope.xlsx"))
    with pytest.raises(FileNotFoundError, match="data/"):
        load_dataset(cfg)


def test_load_dataset_rejects_nan(tmp_path, synthetic_frame):
    path = tmp_path / "nan.csv"
    df = synthetic_frame.copy()
    df.loc[3, "f1"] = np.nan
    df.to_csv(path, index=False)
    cfg = DataConfig(path=str(path), feature_columns=list(range(7)), target_column=7)
    with pytest.raises(ValueError, match="NaN"):
        load_dataset(cfg)
